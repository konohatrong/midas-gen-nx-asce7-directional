"""Roof gravity loads (Dead + Roof Live) as line loads on the roof rafters.

Chosen #3 scope: user-input Dead and Roof Live pressures -> separate static load
cases, applied as global DOWNWARD (-Z) line loads on the roof members. Per the
usual convention:
  - Dead acts ALONG the slope (per actual roof area)      -> USE_PROJECTION=False
  - Roof Live acts on the HORIZONTAL projection (plan area)-> USE_PROJECTION=True

Pressures are in the compute core's base unit (SI N/m^2, US lb/ft^2), same as the
wind core, so the MIDAS edge converts them with the same line_load_to_model path.
Pure; no MIDAS.
"""
from __future__ import annotations

from .geometry import Building
from .loads import MemberLoad, LoadSegment

# load TYPE codes for /db/STLD (so the MIDAS cases aren't tagged as wind)
GRAVITY_CASE_TYPES = {"Dead": "D", "Roof Live": "L"}


def _roof_load(building: Building, roles, w_per_area: float, case: str,
               projection: bool):
    """One downward (-Z) line load per roof member per frame; w = pressure * trib.
    Per-SIDE tributary (same as wind): on a splayed/tapered plan the leeward eave
    line is longer, so LWroof carries more width than WWroof on the same frame."""
    members = []
    for i in range(building.n_frames):
        t_ww = building.tributary_windward(i)
        t_lw = building.tributary_leeward(i)
        trib = {"WWroof": t_ww, "LWroof": t_lw, "ROOF": (t_ww + t_lw) / 2.0}
        for role in roles:
            w = w_per_area * trib[role]               # force/length, down (negative)
            members.append(MemberLoad(i, role, case, [
                LoadSegment(0.0, 1.0, w, w, "GZ", 0.0, use_projection=projection)]))
    return members


def roof_gravity_cases(building: Building, dead: float = 0.0,
                       live: float = 0.0) -> dict:
    """{case_name: [MemberLoad]} for the non-zero roof gravity loads.

    dead / live are downward roof pressures (>= 0) in the core base unit. Dead is
    applied along the slope; Roof Live on the horizontal projection.
    """
    roles = ("ROOF",) if building.is_monoslope else ("WWroof", "LWroof")
    out: dict = {}
    if dead:
        out["Dead"] = _roof_load(building, roles, -abs(dead), "Dead",
                                 projection=False)
    if live:
        out["Roof Live"] = _roof_load(building, roles, -abs(live), "Roof Live",
                                      projection=True)
    return out
