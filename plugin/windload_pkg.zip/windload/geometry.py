"""Building geometry for the wind load generator.

A regular building: transverse frames at positions along the ridge axis, each of
the same span/eave/slope. Two roof types:
  - "gable":     2 columns + 2 rafters; ridge at mid-span (peak = eave + (span/2)tanθ).
  - "monoslope": 2 columns + 1 rafter; single plane rising from the low eave (X=0,
                 height = eave_height) to the high eave (X=span,
                 height = eave_height + span·tanθ).

Derives the ratios ASCE 7-22 needs (h, h/L, L/B) and the per-frame tributary widths
(handles NON-UNIFORM bays). Pure data + math; no MIDAS.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class EndPost:
    """A gable-end wind column (post)."""
    end_idx: int        # 0 = first gable end (Y=min), 1 = last (Y=max)
    post_idx: int       # 1..n across the span
    x: float            # X position across the gable
    y: float            # Y of the gable end
    height: float       # post height (gable profile at x)
    tributary: float    # X tributary width


@dataclass
class Building:
    frame_positions: list[float]   # WINDWARD column coords along the ridge axis (Y)
    span: float                    # eave-to-eave, across the frame (the X dim)
    eave_height: float
    roof_angle_deg: float
    frame_positions_leeward: list[float] | None = None  # LEEWARD column Y coords, if
    #   the leeward columns sit at DIFFERENT Y than the windward (full-irregular skewed
    #   frames). None -> aligned (= frame_positions). Gives windward vs leeward columns
    #   independent tributary widths along the length.
    eave_heights: list[float] | None = None  # per-frame eave height (the eave line
    #   varies/steps along the length). None -> uniform `eave_height` everywhere.
    overhang: float = 0.0          # eave/end overhang added to end tributaries
    n_end_posts: int = 0           # intermediate gable-end wind posts per end
    roof_type: str = "gable"       # "gable" | "monoslope"
    roof_angle_deg2: float | None = None   # right (X=span) slope for UNEQUAL-pitch
    #                                        gable; None -> symmetric (= roof_angle_deg)
    explicit_end_posts: list | None = None  # real posts from a PULL (overrides the
    #   idealized even-spacing generation). When set, end_posts() returns these and
    #   corner tributaries follow their actual X positions (see #3).
    width_windward: float | None = None     # plan width (perp to span, the Y dim) at
    width_leeward: float | None = None       #   the windward / leeward long wall. None
    #   -> use `length` (rectangle). When they differ (irregular/trapezoidal plan) the
    #   leeward-wall Cp uses the width giving the most CONSERVATIVE Cp (#1).
    span_end: float | None = None            # TAPERED plan: span at the LAST gable end
    #   (`span` is the FIRST end). None -> uniform. Linear interpolation along the
    #   length, constant roof angle (so ridge height varies per frame). Per-frame
    #   coefficients. See *_at(i) methods.
    taper_ref: str = "center"                # which long wall stays straight as the
    #   span tapers: "center" (symmetric splay), "windward" (windward wall straight,
    #   leeward splays), or "leeward" (leeward straight, windward splays). #1
    ridge_aligned: bool = False              # tapered + one-sided: keep the ridge at a
    #   CONSTANT X (parallel to the straight wall) and constant height; the tapering
    #   side's roof angle then VARIES per frame (flattens as it widens). The straight
    #   side keeps its input angle. Fixed by the first frame's natural ridge.
    span_per_frame: list[float] | None = None   # EXPLICIT per-frame spans (from a
    #   PULL): real measured values override the linear span->span_end idealization
    #   (same philosophy as explicit_end_posts). None -> span / linear taper.
    wall_x_windward: list[float] | None = None  # EXPLICIT windward-eave X per frame
    #   (from a PULL, local coords): real measured wall line overrides the taper_ref
    #   alignment idealization. None -> derived from taper_ref.
    ridge_x_per_frame: list[float] | None = None  # EXPLICIT per-frame ridge apex X
    #   (from a PULL; measured from that frame's windward eave): real ridge line
    #   overrides the angle-derived position — covers ridge-aligned tapers and any
    #   designed per-frame pitch variation. None -> derived from the angles.
    ridge_z_per_frame: list[float] | None = None  # EXPLICIT per-frame ridge apex
    #   height (from a PULL). With these set, angle_left_at/right_at derive each
    #   frame's REAL pitches from the measured apex. None -> derived.

    def __post_init__(self):
        if len(self.frame_positions) < 1:
            raise ValueError("need at least one frame")
        if any(b <= a for a, b in zip(self.frame_positions,
                                      self.frame_positions[1:])):
            raise ValueError("frame_positions must be strictly increasing")
        if self.span <= 0 or self.eave_height <= 0:
            raise ValueError("span and eave_height must be positive")
        if self.roof_type not in ("gable", "monoslope"):
            raise ValueError("roof_type must be 'gable' or 'monoslope'")
        if self.roof_angle_deg2 is not None and self.roof_angle_deg2 <= 0:
            raise ValueError("roof_angle_deg2 must be positive")
        if self.span_end is not None and self.span_end <= 0:
            raise ValueError("span_end must be positive")
        if self.taper_ref not in ("center", "windward", "leeward"):
            raise ValueError("taper_ref must be 'center', 'windward', or 'leeward'")
        fl = self.frame_positions_leeward
        if fl is not None:
            if len(fl) != len(self.frame_positions):
                raise ValueError("frame_positions_leeward must match frame_positions "
                                 "length")
            if any(b <= a for a, b in zip(fl, fl[1:])):
                raise ValueError("frame_positions_leeward must be strictly increasing")
        if self.eave_heights is not None:
            if len(self.eave_heights) != len(self.frame_positions):
                raise ValueError("eave_heights must match frame_positions length")
            if any(h <= 0 for h in self.eave_heights):
                raise ValueError("eave_heights must be positive")
        if self.span_per_frame is not None:
            if len(self.span_per_frame) != len(self.frame_positions):
                raise ValueError("span_per_frame must match frame_positions length")
            if any(s <= 0 for s in self.span_per_frame):
                raise ValueError("span_per_frame entries must be positive")
        if self.wall_x_windward is not None and \
                len(self.wall_x_windward) != len(self.frame_positions):
            raise ValueError("wall_x_windward must match frame_positions length")
        for nm in ("ridge_x_per_frame", "ridge_z_per_frame"):
            v = getattr(self, nm)
            if v is not None and len(v) != len(self.frame_positions):
                raise ValueError(f"{nm} must match frame_positions length")

    def eave_at(self, i: int) -> float:
        """Eave height of frame i (per-frame eave line, else uniform eave_height)."""
        if self.eave_heights is not None:
            return self.eave_heights[i]
        return self.eave_height

    @property
    def is_monoslope(self) -> bool:
        return self.roof_type == "monoslope"

    # --- taper (per-frame span; #tapered) -----------------------------------
    @property
    def is_tapered(self) -> bool:
        if self.span_per_frame is not None:
            return max(self.span_per_frame) - min(self.span_per_frame) > 1e-9
        return self.span_end is not None and abs(self.span_end - self.span) > 1e-9

    def _frac(self, i: int) -> float:
        """Position of frame i along the length, 0 (first end) .. 1 (last end)."""
        y = self.frame_positions
        if len(y) < 2 or y[-1] == y[0]:
            return 0.0
        return (y[i] - y[0]) / (y[-1] - y[0])

    def span_at(self, i: int) -> float:
        """Span of frame i. Explicit per-frame spans (pulled) win; else linear
        taper span -> span_end; uniform otherwise."""
        if self.span_per_frame is not None:
            return self.span_per_frame[i]
        if self.span_end is None:
            return self.span
        return self.span + (self.span_end - self.span) * self._frac(i)

    def windward_eave_x_at(self, i: int) -> float:
        """Absolute X of the windward eave on frame i, per taper alignment (#1).

        'windward' -> windward wall straight at X=0 (leeward splays out);
        'leeward'  -> leeward wall straight at X=max_span (windward splays);
        'center'   -> symmetric splay about the centerline. Uniform -> 0 (= today).
        Explicit per-frame wall X (pulled real geometry) wins over all of these.
        """
        if self.wall_x_windward is not None:
            return self.wall_x_windward[i]
        if self.taper_ref == "windward":
            return 0.0
        max_span = max(self.span_at(j) for j in range(self.n_frames))
        if self.taper_ref == "leeward":
            return max_span - self.span_at(i)
        return (max_span - self.span_at(i)) / 2.0     # center

    def _ridge_ref(self):
        """(mode, run, H_rise) for the ridge-aligned case — fixed by frame 0's
        natural ridge so frame 0 keeps the input angles. `run` is the constant
        horizontal run of the STRAIGHT side; `H_rise` the constant ridge rise."""
        s0 = self.span_at(0)
        tl = math.tan(math.radians(self.angle_left))
        tr = math.tan(math.radians(self.angle_right))
        if self.taper_ref == "leeward":           # leeward straight -> right run const
            lee_run = s0 * tl / (tl + tr) if (tl + tr) else s0 / 2.0
            return ("leeward", lee_run, lee_run * tr)
        ww_run = s0 * tr / (tl + tr) if (tl + tr) else s0 / 2.0   # windward run const
        return ("windward", ww_run, ww_run * tl)

    def ridge_x_at(self, i: int) -> float:
        """Local ridge X (windward eave = 0) for frame i, honoring unequal pitch and
        ridge alignment (constant-X ridge when ridge_aligned). An EXPLICIT measured
        ridge (pulled) wins over the derived position."""
        if self.ridge_x_per_frame is not None and not self.is_monoslope:
            return self.ridge_x_per_frame[i]
        s = self.span_at(i)
        if self.is_monoslope:
            return s
        if self.ridge_aligned and self.is_tapered:
            mode, run, _ = self._ridge_ref()
            return run if mode == "windward" else s - run   # constant absolute X
        tl = math.tan(math.radians(self.angle_left))
        tr = math.tan(math.radians(self.angle_right))
        return s * tr / (tl + tr) if (tl + tr) else s / 2.0

    @property
    def _explicit_ridge(self) -> bool:
        return (self.ridge_x_per_frame is not None
                or self.ridge_z_per_frame is not None)

    def angle_left_at(self, i: int) -> float:
        """Windward-side (X=0) roof angle for frame i (varies if it's the tapering
        side under ridge alignment, or per the MEASURED ridge on a pull)."""
        if self._explicit_ridge and not self.is_monoslope:
            run = self.ridge_x_at(i)
            rise = self.ridge_height_at(i) - self.eave_at(i)
            return (math.degrees(math.atan2(rise, run)) if run > 1e-9
                    else self.angle_left)
        if not (self.ridge_aligned and self.is_tapered and not self.is_monoslope):
            return self.angle_left
        if self.taper_ref != "leeward":            # left side is straight
            return self.angle_left
        _, _, h_rise = self._ridge_ref()           # leeward straight -> left varies
        run = self.ridge_x_at(i)
        return math.degrees(math.atan2(h_rise, run)) if run > 1e-9 else self.angle_left

    def angle_right_at(self, i: int) -> float:
        """Leeward-side (X=span) roof angle for frame i (varies if it's the tapering
        side under ridge alignment, or per the MEASURED ridge on a pull)."""
        if self._explicit_ridge and not self.is_monoslope:
            run = self.span_at(i) - self.ridge_x_at(i)
            rise = self.ridge_height_at(i) - self.eave_at(i)
            return (math.degrees(math.atan2(rise, run)) if run > 1e-9
                    else self.angle_right)
        if not (self.ridge_aligned and self.is_tapered and not self.is_monoslope):
            return self.angle_right
        if self.taper_ref == "leeward":            # right side is straight
            return self.angle_right
        _, _, h_rise = self._ridge_ref()           # windward straight -> right varies
        run = self.span_at(i) - self.ridge_x_at(i)
        return math.degrees(math.atan2(h_rise, run)) if run > 1e-9 else self.angle_right

    def ridge_rise_at(self, i: int) -> float:
        if self.ridge_z_per_frame is not None:
            return max(self.ridge_z_per_frame[i] - self.eave_at(i), 0.0)
        if self.is_monoslope:
            return self.span_at(i) * math.tan(math.radians(self.roof_angle_deg))
        if self.ridge_aligned and self.is_tapered:
            return self._ridge_ref()[2]               # constant rise (ridge level)
        return self.ridge_x_at(i) * math.tan(math.radians(self.angle_left))

    def ridge_height_at(self, i: int) -> float:
        if self.ridge_z_per_frame is not None:        # measured apex (pulled)
            return self.ridge_z_per_frame[i]
        return self.eave_at(i) + self.ridge_rise_at(i)

    def mean_roof_height_at(self, i: int) -> float:
        return (self.eave_at(i) + self.ridge_height_at(i)) / 2.0

    def h_over_L_at(self, i: int, wind: str) -> float:
        L = self.span_at(i) if wind == "normal" else self.length
        return self.mean_roof_height_at(i) / L if L > 0 else 0.0

    def leeward_LoverB_at(self, i: int, wind: str) -> float:
        """Per-frame conservative leeward L/B (taper-aware). Normal: L = span_at(i),
        B = the conservative perpendicular width."""
        if wind != "normal":
            return self.L_over_B("parallel")
        widths = [w for w in (self.width_windward, self.width_leeward, self.length)
                  if w and w > 0]
        B = max(widths) if widths else self.length
        return self.span_at(i) / B if B > 0 else float("inf")

    # --- roof slope angles (left = X=0 side, right = X=span side) ---
    @property
    def angle_left(self) -> float:
        return self.roof_angle_deg

    @property
    def angle_right(self) -> float:
        return (self.roof_angle_deg if self.roof_angle_deg2 is None
                else self.roof_angle_deg2)

    @property
    def is_asymmetric(self) -> bool:
        return (self.roof_type == "gable" and self.roof_angle_deg2 is not None
                and abs(self.angle_right - self.angle_left) > 1e-9)

    # --- derived geometry ---
    @property
    def ridge_x(self) -> float:
        """Horizontal position of the ridge from X=0. Mid-span for a symmetric
        gable; offset toward the steeper slope for an unequal-pitch gable
        (derived from LEVEL eaves). For monoslope, the high eave at X=span."""
        if self.is_monoslope:
            return self.span
        tl = math.tan(math.radians(self.angle_left))
        tr = math.tan(math.radians(self.angle_right))
        return self.span * tr / (tl + tr) if (tl + tr) else self.span / 2.0

    @property
    def ridge_rise(self) -> float:
        """Rise from the eave to the roof peak. Monoslope peak = high eave at
        X=span; gable peak = ridge at ridge_x (works for unequal pitch)."""
        if self.is_monoslope:
            return self.span * math.tan(math.radians(self.roof_angle_deg))
        return self.ridge_x * math.tan(math.radians(self.angle_left))

    @property
    def ridge_height(self) -> float:
        """Height of the roof peak (gable ridge, or monoslope high eave)."""
        return self.eave_height + self.ridge_rise

    @property
    def mean_roof_height(self) -> float:
        """h = average of eave and ridge heights (ASCE 26.2).

        For theta <= 10 deg the standard *permits* h = eave height; we use the
        full average (always valid, slightly more conservative, matches the
        validated prototype).
        """
        return (self.eave_height + self.ridge_height) / 2.0

    @property
    def length(self) -> float:
        """Building length along the ridge."""
        return self.frame_positions[-1] - self.frame_positions[0]

    @property
    def n_frames(self) -> int:
        return len(self.frame_positions)

    @property
    def bays(self) -> list[float]:
        return [b - a for a, b in zip(self.frame_positions,
                                      self.frame_positions[1:])]

    # --- ASCE ratios ---
    def h_over_L(self, wind: str) -> float:
        """h/L. For 'normal' (to ridge) L = span; for 'parallel' L = length."""
        L = self.span if wind == "normal" else self.length
        return self.mean_roof_height / L if L > 0 else 0.0

    def L_over_B(self, wind: str) -> float:
        """L/B for leeward-wall Cp. L parallel to wind, B perpendicular."""
        if wind == "normal":          # wind across the frame
            L, B = self.span, self.length
        else:                          # wind along the ridge
            L, B = self.length, self.span
        return L / B if B > 0 else float("inf")

    def leeward_LoverB(self, wind: str) -> float:
        """L/B for the leeward wall, choosing the CONSERVATIVE width on an irregular
        plan (#1). Leeward Cp magnitude is largest at small L/B and decreases as L/B
        grows, so the conservative choice is the LARGEST perpendicular width B (=
        smallest L/B = most-negative Cp = largest suction adding to the lateral load).

        Normal-to-ridge: L = span, B = max(windward, leeward, nominal length).
        Parallel-to-ridge: the leeward wall is a gable end, B = span (fixed) -> the
        plain L_over_B (the long-wall widths don't apply across the gable end).
        """
        if wind != "normal":
            return self.L_over_B("parallel")
        widths = [w for w in (self.width_windward, self.width_leeward, self.length)
                  if w and w > 0]
        B = max(widths) if widths else self.length
        return self.span / B if B > 0 else float("inf")

    # --- tributary widths (per frame; unequal bays handled) ---
    def tributary(self, i: int) -> float:
        y = self.frame_positions
        n = len(y)
        if n == 1:
            return 0.0
        if i == 0:
            return (y[1] - y[0]) / 2.0 + self.overhang
        if i == n - 1:
            return (y[-1] - y[-2]) / 2.0 + self.overhang
        return (y[i + 1] - y[i - 1]) / 2.0

    def tributaries(self) -> list[float]:
        return [self.tributary(i) for i in range(self.n_frames)]

    # --- per-side tributary (windward vs leeward wall can differ in length) ---
    # On a tapered/splayed plan the windward and leeward eave lines have different
    # lengths, so the spacing of the frames ALONG each wall differs -> the windward
    # column carries a different tributary than the leeward column on the same frame.
    def y_at(self, i: int, leeward: bool = False) -> float:
        """Y of the windward (or leeward) column on frame i. Leeward may differ
        (full-irregular skewed frames) when frame_positions_leeward is set."""
        if leeward and self.frame_positions_leeward is not None:
            return self.frame_positions_leeward[i]
        return self.frame_positions[i]

    def _eave_line(self, leeward: bool) -> list:
        out = []
        for i in range(self.n_frames):
            x = self.windward_eave_x_at(i) + (self.span_at(i) if leeward else 0.0)
            out.append((x, self.y_at(i, leeward)))
        return out

    def _trib_along(self, pts: list, i: int) -> float:
        n = len(pts)
        if n == 1:
            return 0.0

        def d(a, b):
            return math.hypot(b[0] - a[0], b[1] - a[1])
        if i == 0:
            return d(pts[0], pts[1]) / 2.0 + self.overhang
        if i == n - 1:
            return d(pts[-2], pts[-1]) / 2.0 + self.overhang
        return (d(pts[i - 1], pts[i]) + d(pts[i], pts[i + 1])) / 2.0

    def tributary_windward(self, i: int) -> float:
        """Frame i tributary measured ALONG the windward eave line."""
        return self._trib_along(self._eave_line(leeward=False), i)

    def tributary_leeward(self, i: int) -> float:
        """Frame i tributary measured ALONG the leeward eave line (longer on a
        splayed plan -> larger tributary than the windward side)."""
        return self._trib_along(self._eave_line(leeward=True), i)

    def wall_x_at(self, i: int, leeward: bool) -> float:
        """X position of the windward/leeward long wall at frame i."""
        return self.windward_eave_x_at(i) + (self.span_at(i) if leeward else 0.0)

    def proj_tributary(self, i: int, leeward: bool) -> float:
        """SIGNED plan-projected (X) tributary of a long wall at frame i — the width
        of the tapered wall that catches PARALLEL-to-ridge wind and loads frame i.
        0.5*(x_{i+1}-x_{i-1}) (one-sided at the ends). 0 for a wall with no X-taper.
        """
        n = self.n_frames
        if n < 2:
            return 0.0
        if i == 0:
            return (self.wall_x_at(1, leeward) - self.wall_x_at(0, leeward)) / 2.0
        if i == n - 1:
            return (self.wall_x_at(n - 1, leeward)
                    - self.wall_x_at(n - 2, leeward)) / 2.0
        return (self.wall_x_at(i + 1, leeward)
                - self.wall_x_at(i - 1, leeward)) / 2.0

    # --- corner columns (end-frame columns: resist both wind directions) ---
    def end_index_of_frame(self, i: int):
        """Which gable end a frame sits at: 0 (Y=min), 1 (Y=max), or None."""
        if i == 0:
            return 0
        if i == self.n_frames - 1:
            return 1
        return None

    @property
    def corner_gable_tributary(self) -> float:
        """X tributary of a corner column on the gable end (= half a post bay).

        Even-spacing form; kept for back-compat. For real (possibly irregular)
        pulled posts use corner_gable_tributary_at(end, side)."""
        return self.span / (2.0 * (self.n_end_posts + 1))

    def _span_of_end(self, end_idx: int) -> float:
        """Span at gable end `end_idx` (0 = first frame, 1 = last) — taper-aware."""
        return self.span_at(0 if end_idx == 0 else self.n_frames - 1)

    def corner_gable_tributary_at(self, end_idx: int, side: str) -> float:
        """X tributary picked up by a corner column on gable end `end_idx`.

        side: 'WW' (column at X=0) or 'LW' (column at X=span_end). The corner spans
        from its wall edge to the half-point toward the nearest end post; with no
        posts each corner carries half that gable's width. Honors irregular spacing
        (explicit posts) and a tapered (per-end) span.
        """
        s_end = self._span_of_end(end_idx)
        xs = sorted(ep.x for ep in self.end_posts() if ep.end_idx == end_idx)
        if not xs:
            return s_end / 2.0
        if side == "WW":                 # column at X=0 -> half-way to first post
            return xs[0] / 2.0
        return (s_end - xs[-1]) / 2.0    # column at X=span_end -> from last post

    # --- gable-end wind posts ---
    def _roof_z(self, x: float, span: float, eave: float | None = None) -> float:
        """Roof height above local X for a given span (used per gable end).
        `eave` overrides the uniform eave_height (per-frame eave line)."""
        ev = self.eave_height if eave is None else eave
        if self.is_monoslope:
            return ev + x * math.tan(
                math.radians(self.roof_angle_deg))
        if self.ridge_aligned and self.is_tapered:
            mode, run, h_rise = self._ridge_ref()
            H = ev + h_rise
            if mode == "windward":               # windward run R const, leeward varies
                R = run
                if x <= R:
                    return ev + x * math.tan(math.radians(self.angle_left))
                lee = span - R
                return H - (x - R) * (h_rise / lee) if lee > 1e-9 else H
            x_r = span - run                      # leeward straight: ridge X from WW eave
            if x >= x_r:
                return ev + (span - x) * math.tan(math.radians(self.angle_right))
            return H - (x_r - x) * (h_rise / x_r) if x_r > 1e-9 else H
        tl = math.tan(math.radians(self.angle_left))
        tr = math.tan(math.radians(self.angle_right))
        xr = span * tr / (tl + tr) if (tl + tr) else span / 2.0
        if x <= xr:
            return ev + x * tl
        return ev + (span - x) * tr

    def roof_z_at(self, x: float) -> float:
        """Roof height above an X position (uses the first-end span + eave)."""
        return self._roof_z(x, self.span, self.eave_at(0))

    def end_posts(self) -> list[EndPost]:
        """Gable-end wind posts. Real pulled posts (explicit_end_posts) win over
        the idealized even-spacing generation used by the generate path."""
        if self.explicit_end_posts is not None:
            return list(self.explicit_end_posts)
        if self.n_end_posts <= 0:
            return []
        ends = [self.frame_positions[0], self.frame_positions[-1]]
        out: list[EndPost] = []
        for ei, y in enumerate(ends):
            span_e = self._span_of_end(ei)               # taper-aware per-end span
            eave_e = self.eave_at(0 if ei == 0 else self.n_frames - 1)  # per-end eave
            s = span_e / (self.n_end_posts + 1)
            for p in range(1, self.n_end_posts + 1):
                x = p * s
                out.append(EndPost(ei, p, x, y, self._roof_z(x, span_e, eave_e), s))
        return out

    @staticmethod
    def posts_with_tributaries(span: float, posts: list,
                               span_by_end: dict | None = None) -> list:
        """Return EndPost copies with X-tributaries set from ACTUAL spacing.

        Posts at the same end are bounded by the corner columns at X=0 and
        X=span (post x measured from that end's windward eave); each post's
        tributary is half the distance to its neighbors (corner or post).
        span_by_end {0: span0, 1: span1} overrides `span` per gable end (taper).
        Input posts need end_idx/post_idx/x/y/height; tributary is filled.
        """
        out: list = []
        by_end: dict = {}
        for ep in posts:
            by_end.setdefault(ep.end_idx, []).append(ep)
        for end_idx, plist in by_end.items():
            span_e = (span_by_end or {}).get(end_idx, span)
            plist = sorted(plist, key=lambda e: e.x)
            bounds = [0.0] + [e.x for e in plist] + [span_e]
            for j, ep in enumerate(plist, start=1):     # j indexes into bounds
                trib = (bounds[j + 1] - bounds[j - 1]) / 2.0
                out.append(EndPost(ep.end_idx, j, ep.x, ep.y, ep.height, trib))
        return out
