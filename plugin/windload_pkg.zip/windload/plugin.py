"""Pure plug-in API — the surface the Pyodide (browser) layer calls.

Each function takes raw MIDAS /db JSON (fetched by the JS MAPI layer) and returns
plain JSON-able dicts (report / preview / STLD-LDGR-BMLD payloads to PUT). No
midas_gen, no HTTP — all engineering is the same validated compute core used by
the desktop tool. The plug-in does HTTP in JS and the math here via Pyodide.
"""
from __future__ import annotations

from .units import get_units
from .loads import WindParams, compute_loads, filter_surfaces
from .report import preview
from .midas.pull import parse_model
from .midas.classify import reconstruct
from .midas.payload import (bmld_payload, stld_payload, ldgr_payload,
                            bmld_item_count, merge_bmld)
from .midas.build import TAGGING_GROUPS

_TAG_EXACT = {"wwcol", "lwcol", "wwroof", "lwroof", "roof", "corner"}


def grup_payload(existing_grup: dict, names=None) -> dict:
    """Non-destructive /db/GRUP payload: keep every existing group, add only the
    missing tagging groups with fresh IDs. Same logic as build.create_tagging_groups
    (which can't run in-browser because it uses midas_gen for the GET/PUT)."""
    names = names or TAGGING_GROUPS
    present = {v.get("NAME") for v in existing_grup.values()}
    assign = {k: {"NAME": v.get("NAME", ""), "P_TYPE": v.get("P_TYPE", 0),
                  "N_LIST": v.get("N_LIST", []), "E_LIST": v.get("E_LIST", [])}
              for k, v in existing_grup.items()}
    next_id = max((int(k) for k in existing_grup), default=0) + 1
    created, skipped = [], []
    for nm in names:
        if nm in present:
            skipped.append(nm)
            continue
        assign[str(next_id)] = {"NAME": nm, "P_TYPE": 0, "N_LIST": [], "E_LIST": []}
        present.add(nm)
        created.append(nm)
        next_id += 1
    return {"assign": {"Assign": assign}, "created": created,
            "skipped": skipped, "existing_kept": len(existing_grup)}


def _is_wind_tag(name: str) -> bool:
    n = name.strip().lower()
    return n in _TAG_EXACT or n.startswith("endwall") or n.startswith("epost")


def tag_summary(grup_json: dict, n_elements: int) -> dict:
    """Recognized tagging groups + element coverage (for connect/refresh)."""
    groups: dict = {}
    tagged: set = set()
    for v in grup_json.values():
        nm = v.get("NAME", "")
        if nm and _is_wind_tag(nm):
            es = [int(e) for e in (v.get("E_LIST", []) or [])]
            groups[nm] = len(es)
            tagged.update(es)
    return {"total_elements": n_elements, "groups": groups,
            "group_count": len(groups), "tagged_elements": len(tagged),
            "has_tags": bool(groups)}


def _wind(w: dict) -> WindParams:
    zh = w.get("wall_zone_height")
    zs = w.get("wall_zone_heights")
    return WindParams(V=float(w["V"]), exposure=w.get("exposure", "C"),
                      units=get_units(w.get("units", "SI")),
                      Kzt=float(w.get("Kzt", 1.0)), Ke=float(w.get("Ke", 1.0)),
                      enclosure=w.get("enclosure", "enclosed"),
                      G=float(w.get("G", 0.85)),
                      wall_zone_height=(float(zh) if zh else None),
                      wall_zone_heights=([float(z) for z in zs] if zs else None),
                      wall_qz_at=w.get("wall_qz_at", "mid"))


def _report_dict(r) -> dict:
    return {"roof_type": r.roof_type, "n_frames": r.n_frames,
            "frame_positions": r.frame_positions, "span": r.span,
            "eave_height": r.eave_height, "ridge_height": r.ridge_height,
            "roof_angle_deg": r.roof_angle_deg, "roof_angle_deg2": r.roof_angle_deg2,
            "tributaries": r.tributaries, "role_counts": r.role_counts,
            "end_posts": r.end_posts, "meshed_members": r.meshed_members,
            "end_posts_detail": r.end_posts_detail,
            "frames_detail": r.frames_detail,
            "warnings": r.warnings, "notes": r.notes}


def _pull_local(node_json, elem_json, grup_json, ridge_azimuth_deg=90.0):
    """parse -> world->local transform (user ridge azimuth, auto origin) ->
    reconstruct, with the applied transform noted in the report."""
    from .midas.transform import to_local
    raw, tf = to_local(parse_model(node_json, elem_json, grup_json),
                       ridge_azimuth_deg)
    pulled = reconstruct(raw)
    ox, oy, oz = tf["origin_world"]
    pulled.report.notes.append(
        f"orientation: ridge azimuth {ridge_azimuth_deg:g} deg (from +X, CCW+); "
        f"auto origin at world ({ox:.3f}, {oy:.3f}, {oz:.3f})")
    return pulled


def existing_model_report(node_json, elem_json, grup_json, wind, directions,
                          ridge_azimuth_deg=90.0, mode="wind",
                          dead=0.0, live=0.0, meta=None) -> dict:
    """Pull + reconstruct + build the step-by-step calculation-report dict
    (calcreport.build_calc_report) for the model open in GEN NX. The JS layer
    renders it to PDF (jsPDF) — same data source as the desktop report."""
    from .calcreport import build_calc_report
    pulled = _pull_local(node_json, elem_json, grup_json, ridge_azimuth_deg)
    w = _wind(wind)
    return build_calc_report(pulled.building, w, list(directions) or ["+X"],
                             mode=mode, dead=float(dead), live=float(live),
                             ridge_azimuth_deg=ridge_azimuth_deg,
                             meta=meta or {})


def existing_model_review(node_json, elem_json, grup_json, wind, directions,
                          ridge_azimuth_deg=90.0) -> dict:
    """Pull + reconstruct + preview (no writes). For the GUI verify step."""
    pulled = _pull_local(node_json, elem_json, grup_json, ridge_azimuth_deg)
    w = _wind(wind)
    dirs = list(directions) or ["+X"]
    return {"report": _report_dict(pulled.report),
            "preview": preview(pulled.building, w, dirs)}


def existing_model_assign(node_json, elem_json, grup_json, wind, directions,
                          force_unit="KN", dist_unit="M",
                          existing_stld=None, existing_ldgr=None,
                          existing_bmld=None, surfaces=None,
                          ridge_azimuth_deg=90.0,
                          mode="wind", dead=0.0, live=0.0) -> dict:
    """Pull + reconstruct + compute + build the STLD/LDGR/BMLD payloads to PUT.

    mode:
      "wind" — directional wind only (the given directions x +/-GCpi).
      "full" — the FULL ordered professional set (same as runner.assign_full_to_
               existing): Dead, Roof Live (from `dead`/`live` roof pressures in
               the core base unit), wind for the given directions, then the 48
               MWFRS C1-C4 cases.
    The returned `bmld` is a non-destructive merge (choice b): it replaces only
    this run's own cases per element and preserves Dead/Live/EQ and other wind
    directions. The JS layer should GET /db/BMLD and pass it as `existing_bmld`
    (the 'BMLD' dict); without it the merge is a no-op (new only). `bmld_count`
    is the number of NEW items added. The returned `case_types` maps non-wind
    case names to their STLD TYPE (already applied to the stld payload).
    """
    pulled = _pull_local(node_json, elem_json, grup_json, ridge_azimuth_deg)
    w = _wind(wind)
    dirs = list(directions) or ["+X"]
    cases: dict = {}
    case_types = None
    if mode == "wind_mwfrs":            # full set without gravity (56 cases)
        mode, dead, live = "full", 0.0, 0.0
    if mode == "full":
        from .gravity import roof_gravity_cases, GRAVITY_CASE_TYPES
        from .mwfrs import mwfrs_cases
        from .ordering import order_cases
        cases.update(roof_gravity_cases(pulled.building, float(dead), float(live)))
        for d in dirs:
            cases.update(compute_loads(pulled.building, w, d))
        cases.update(mwfrs_cases(pulled.building, w, axes=tuple(dirs)))
        cases = order_cases(filter_surfaces(cases, surfaces))
        case_types = GRAVITY_CASE_TYPES
    else:
        for d in dirs:
            cases.update(compute_loads(pulled.building, w, d))
        cases = filter_surfaces(cases, surfaces)        # #4 per-surface selection
    names = list(cases)
    new_bmld = bmld_payload(cases, pulled.role_map, w.units, force_unit, dist_unit,
                            ridge_azimuth_deg=ridge_azimuth_deg)
    bmld = merge_bmld(existing_bmld or {}, new_bmld, own_case_names=names)
    return {"report": _report_dict(pulled.report),
            "preview": preview(pulled.building, w, dirs),
            "stld": stld_payload(names, existing_stld or {}, types=case_types),
            "ldgr": ldgr_payload(names, existing_ldgr or {}),
            "bmld": bmld, "cases": names,
            "bmld_count": bmld_item_count(new_bmld)}
