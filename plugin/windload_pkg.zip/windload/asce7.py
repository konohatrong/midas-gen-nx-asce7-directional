"""ASCE 7-22 wind core — MWFRS Directional Procedure (Ch 26-27).

Pure functions over verified values (see docs/ASCE7-22_VALUES.md). No MIDAS, no
I/O. Everything here is unit-tested against hand calcs / the prototypes.

Key 7-22 note: Kd is NOT in qz; it appears in the design-pressure Eq 27.3-1:
    qz = c * Kz * Kzt * Ke * V^2
    p  = q * Kd * G * Cp  -  qi * Kd * (GCpi)
"""
from __future__ import annotations

from .units import UnitSystem, US

KD_BUILDING = 0.85       # Table 26.6-1 (buildings, MWFRS)
G_RIGID = 0.85           # Section 26.11.1

# Internal pressure coefficient, Table 26.13-1 (magnitude; +/- are the two cases)
GCPI = {
    "enclosed": 0.18,
    "partially_enclosed": 0.55,
    "partially_open": 0.18,
    "open": 0.0,
}

# Terrain exposure constants, Table 26.11-1
_TERRAIN = {
    "B": dict(alpha=7.5, zg_ft=3280.0, zg_m=1000.0, zmin_ft=30.0, zmin_m=9.14),
    "C": dict(alpha=9.8, zg_ft=2460.0, zg_m=750.0, zmin_ft=15.0, zmin_m=4.57),
    "D": dict(alpha=11.5, zg_ft=1935.0, zg_m=590.0, zmin_ft=7.0, zmin_m=2.13),
}


# --------------------------------------------------------------------------- #
# Velocity pressure
# --------------------------------------------------------------------------- #
def kz(z: float, exposure: str, units: UnitSystem) -> float:
    """Velocity-pressure exposure coefficient (Table 26.10-1 / its formula)."""
    t = _TERRAIN[exposure.upper()]
    zg = t["zg_ft"] if units is US else t["zg_m"]
    zmin = t["zmin_ft"] if units is US else t["zmin_m"]
    zc = min(max(z, zmin), zg)
    return 2.41 * (zc / zg) ** (2.0 / t["alpha"])


def qz(z: float, V: float, exposure: str, units: UnitSystem,
       Kzt: float = 1.0, Ke: float = 1.0) -> float:
    """Velocity pressure at height z (Eq 26.10-1). NOTE: no Kd in 7-22."""
    return units.qz_const * kz(z, exposure, units) * Kzt * Ke * V * V


def design_pressure(q: float, cp: float, qh: float, gcpi_signed: float,
                    Kd: float = KD_BUILDING, G: float = G_RIGID) -> float:
    """Net design pressure p (Eq 27.3-1). gcpi_signed = +/-GCpi (qi = qh)."""
    return q * Kd * G * cp - qh * Kd * gcpi_signed


# --------------------------------------------------------------------------- #
# Wall pressure coefficients (Fig 27.3-1)
# --------------------------------------------------------------------------- #
def cp_windward_wall() -> float:
    return 0.8                       # use with qz


def cp_side_wall() -> float:
    return -0.7                      # use with qh


def cp_leeward_wall(L_over_B: float) -> float:
    """Leeward wall Cp by L/B (use with qh). -0.5 (<=1) .. -0.2 (>=4)."""
    if L_over_B <= 1.0:
        return -0.5
    if L_over_B >= 4.0:
        return -0.2
    if L_over_B <= 2.0:
        return _interp(L_over_B, 1.0, -0.5, 2.0, -0.3)
    return _interp(L_over_B, 2.0, -0.3, 4.0, -0.2)


# --------------------------------------------------------------------------- #
# Roof pressure coefficients (Fig 27.3-1) — all use qh
# --------------------------------------------------------------------------- #
# Windward roof, wind NORMAL to ridge, theta >= 10 deg. Each cell = the two Cp
# values to design for (min/uplift, max). Single-value cells repeat the value.
_WW_ROOF = {
    0.25: {10: (-0.7, -0.18), 15: (-0.5, 0.0), 20: (-0.3, 0.2),
           25: (-0.2, 0.3), 30: (-0.2, 0.3), 35: (0.0, 0.4),
           45: (0.4, 0.4), 60: (0.6, 0.6)},
    0.5:  {10: (-0.9, -0.18), 15: (-0.7, -0.18), 20: (-0.4, 0.0),
           25: (-0.3, 0.2), 30: (-0.2, 0.2), 35: (-0.2, 0.3),
           45: (0.0, 0.4), 60: (0.6, 0.6)},
    1.0:  {10: (-1.3, -0.18), 15: (-1.0, -0.18), 20: (-0.7, -0.18),
           25: (-0.5, 0.0), 30: (-0.3, 0.2), 35: (-0.2, 0.2),
           45: (0.0, 0.3), 60: (0.6, 0.6)},
}
# Leeward roof, wind normal to ridge, theta >= 10 deg.
_LW_ROOF = {
    0.25: {10: -0.3, 15: -0.5, 20: -0.6},
    0.5:  {10: -0.5, 15: -0.5, 20: -0.6},
    1.0:  {10: -0.7, 15: -0.6, 20: -0.6},
}
_HL_ROWS = (0.25, 0.5, 1.0)


def cp_windward_roof(h_over_L: float, theta_deg: float) -> tuple[float, float]:
    """(cp_min, cp_max) windward roof, normal to ridge, theta >= 10 deg."""
    if theta_deg < 10.0:
        raise ValueError("theta < 10: use cp_roof_zoned (low-slope is zoned)")
    lo = _interp_hl(h_over_L, lambda row: _roof_angle_pair(_WW_ROOF[row], theta_deg))
    return (min(lo), max(lo))


def cp_leeward_roof(h_over_L: float, theta_deg: float) -> float:
    """Leeward roof Cp, normal to ridge, theta >= 10 deg."""
    th = min(max(theta_deg, 10.0), 20.0)
    return _interp_hl(h_over_L, lambda row: _interp_angle_single(_LW_ROOF[row], th))


# Low-slope (theta < 10, normal to ridge) AND parallel-to-ridge (all theta):
# zoned by horizontal distance x from the windward edge, in terms of h.
def cp_roof_zoned(x: float, h: float, h_over_L: float) -> tuple[float, float]:
    """(cp_primary, cp_alt) at horizontal distance x from windward edge.

    cp_alt is the +/-0.18 alternate per the figure.
    """
    if h_over_L <= 0.5:
        if x <= 1.0 * h:
            cp = -0.9
        elif x <= 2.0 * h:
            cp = -0.5
        else:
            cp = -0.3
    else:                                  # h/L >= 1.0
        cp = -1.3 if x <= 0.5 * h else -0.7
    return (cp, -0.18)


def roof_zone_bounds(h: float, span: float, h_over_L: float) -> list[float]:
    """Horizontal x-boundaries of the zoned roof distribution (windward edge=0)."""
    if h_over_L <= 0.5:
        bounds = [0.0, h, 2.0 * h, span]
    else:
        bounds = [0.0, 0.5 * h, span]
    return [b for b in bounds if 0.0 <= b <= span] + (
        [span] if bounds[-1] < span else [])


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _interp(x, x0, y0, x1, y1):
    if x1 == x0:
        return y0
    return y0 + (y1 - y0) * (x - x0) / (x1 - x0)


def _interp_hl(h_over_L, row_value):
    """Interpolate a per-row scalar/sequence across the h/L table rows."""
    hl = min(max(h_over_L, _HL_ROWS[0]), _HL_ROWS[-1])
    for r0, r1 in zip(_HL_ROWS[:-1], _HL_ROWS[1:]):
        if r0 <= hl <= r1:
            v0, v1 = row_value(r0), row_value(r1)
            if isinstance(v0, tuple):
                return tuple(_interp(hl, r0, a, r1, b) for a, b in zip(v0, v1))
            return _interp(hl, r0, v0, r1, v1)
    return row_value(_HL_ROWS[-1])


def _roof_angle_pair(row: dict, theta: float) -> tuple[float, float]:
    """Angle-interpolated (v1, v2) within a windward-roof h/L row."""
    angles = sorted(row)
    if theta <= angles[0]:
        return row[angles[0]]
    if theta >= angles[-1]:
        if theta <= 80.0:
            v = 0.01 * theta
            return (v, v)
        return (0.8, 0.8)
    for a0, a1 in zip(angles[:-1], angles[1:]):
        if a0 <= theta <= a1:
            p0, p1 = row[a0], row[a1]
            return (_interp(theta, a0, p0[0], a1, p1[0]),
                    _interp(theta, a0, p0[1], a1, p1[1]))
    return row[angles[-1]]


def _interp_angle_single(row: dict, theta: float) -> float:
    angles = sorted(row)
    if theta <= angles[0]:
        return row[angles[0]]
    if theta >= angles[-1]:
        return row[angles[-1]]
    for a0, a1 in zip(angles[:-1], angles[1:]):
        if a0 <= theta <= a1:
            return _interp(theta, a0, row[a0], a1, row[a1])
    return row[angles[-1]]
