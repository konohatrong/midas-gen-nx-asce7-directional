"""Step-by-step calculation report (pure; no MIDAS, no PDF library).

Builds a JSON-able report dict that a renderer (PDF on the server, print-HTML in
the plug-in) can lay out. Every step echoes its inputs, shows the substituted
formula, and — where possible — carries a CHECK column the reviewer can verify:

  - Step 3: the internal-pressure half-difference (p- − p+)/2 must equal
    qh·Kd·GCpi on EVERY row (a strong row-by-row self-check).
  - Step 5: each MWFRS case's relative base shear must equal its Fig 27.3-8
    factor × the matching full-wind case (ratio check, lengths cancel).

All pressures are in the unit system's base pressure unit (SI N/m², US lb/ft²);
line loads in pressure×length (N/m, lb/ft).
"""
from __future__ import annotations

import math

from . import asce7
from .geometry import Building
from .loads import WindParams, compute_loads
from .mwfrs import CASE_FACTORS, ECCENTRICITY


_R = lambda x, n=3: round(x, n)                      # noqa: E731


def _rel_shear(members, axis: str) -> float:
    """Relative (signed) horizontal resultant in axis 'GX'|'GY' — w·Δd sums.
    Lengths cancel in the ratio checks the report uses this for."""
    s = 0.0
    for m in members:
        for seg in m.segments:
            if seg.direction == axis:
                s += (seg.w0 + seg.w1) / 2.0 * abs(seg.d1 - seg.d0)
    return s


def _inputs_section(b: Building, w: WindParams, directions, mode,
                    dead, live, ridge_azimuth_deg) -> dict:
    g = {
        "roof type": b.roof_type + (" (unequal pitch)" if b.is_asymmetric else ""),
        "frames / bays": f"{b.n_frames} frames · bays "
                         f"{[_R(x,2) for x in b.bays]}",
        "span (eave-eave)": _R(b.span, 3),
        "eave height": _R(b.eave_height, 3),
        "ridge height": _R(b.ridge_height, 3),
        "roof angle θ": (f"{_R(b.angle_left,2)}° / {_R(b.angle_right,2)}°"
                          if b.is_asymmetric else f"{_R(b.roof_angle_deg,2)}°"),
        "building length B(Y)": _R(b.length, 3),
        "end posts / end": b.n_end_posts,
        "ridge azimuth": f"{ridge_azimuth_deg}° from +X (CCW+)",
    }
    if getattr(b, "span_end", None):
        g["span @ last end (taper)"] = _R(b.span_end, 3)
    wd = {
        "V (basic wind speed)": f"{w.V} {w.units.speed}",
        "exposure": w.exposure, "units": w.units.name,
        "Kzt": w.Kzt, "Ke": w.Ke,
        "Kd (Table 26.6-1)": w.Kd, "G (§26.11)": w.G,
        "enclosure → GCpi (Table 26.13-1)": f"{w.enclosure} → ±{w.gcpi}",
        "directions": ", ".join(directions),
        "load set": {"wind": "directional wind",
                     "mwfrs": "MWFRS 48-case (Fig 27.3-8)",
                     "wind_mwfrs": "Wind + MWFRS (8 wind + 48 MWFRS = 56 cases)",
                     "full": "FULL 58-case (Dead, Roof Live, wind, MWFRS)"
                     }.get(mode, mode),
    }
    if mode == "full":
        wd["roof Dead / Roof Live pressure"] = (
            f"{dead} / {live} {w.units.pressure}")
    if w.wall_zone_heights or w.wall_zone_height:
        wd["windward-wall q_z zoning"] = (
            f"explicit breakpoints {w.wall_zone_heights}"
            if w.wall_zone_heights else
            f"every {w.wall_zone_height} (q_z at zone {w.wall_qz_at})")
    return {"geometry": g, "wind": wd}


def _step1_velocity(b: Building, w: WindParams) -> dict:
    """q_z table at the heights the calc actually uses (Eq 26.10-1)."""
    h = b.mean_roof_height
    zs = {"eave": b.eave_height, "mean roof height h": h,
          "ridge / high eave": b.ridge_height}
    rows = []
    for label, z in zs.items():
        kz = asce7.kz(z, w.exposure, w.units)
        qz = asce7.qz(z, w.V, w.exposure, w.units, w.Kzt, w.Ke)
        rows.append({"location": label, "z": _R(z, 3), "Kz": _R(kz, 4),
                     "qz": _R(qz, 2)})
    qh = asce7.qz(h, w.V, w.exposure, w.units, w.Kzt, w.Ke)
    return {
        "formula": (f"q_z = {w.units.qz_const} · Kz · Kzt({w.Kzt}) · "
                    f"Ke({w.Ke}) · V²({w.V}²)   [{w.units.pressure}]"),
        "reference": "ASCE 7-22 Eq 26.10-1 (Kd is NOT in q_z in 7-22)",
        "rows": rows,
        "qh": _R(qh, 2),
    }


def _step2_coefficients(b: Building, w: WindParams, directions) -> dict:
    h = b.mean_roof_height
    ratios = {
        "h/L (wind normal to ridge)": _R(b.h_over_L("normal")),
        "h/L (wind parallel)": _R(b.h_over_L("parallel")),
        "L/B (normal)": _R(b.L_over_B("normal")),
        "L/B (parallel)": _R(b.L_over_B("parallel")),
    }
    walls = [
        {"surface": "windward wall", "Cp": 0.8, "use with": "q_z",
         "ref": "Fig 27.3-1"},
        {"surface": "leeward wall (normal wind)",
         "Cp": _R(asce7.cp_leeward_wall(b.L_over_B("normal")), 3),
         "use with": "q_h", "ref": f"L/B={_R(b.L_over_B('normal'))}"},
        {"surface": "leeward wall (parallel wind)",
         "Cp": _R(asce7.cp_leeward_wall(b.L_over_B("parallel")), 3),
         "use with": "q_h", "ref": f"L/B={_R(b.L_over_B('parallel'))}"},
        {"surface": "side wall", "Cp": -0.7, "use with": "q_h",
         "ref": "Fig 27.3-1"},
    ]
    roof: dict = {"reference": "Fig 27.3-1 roof tables (per-plane θ)"}
    hl = b.h_over_L("normal")
    th_w = {"+X": b.angle_left, "-X": b.angle_right}
    for d in [x for x in directions if "X" in x]:
        tw = th_w.get(d, b.roof_angle_deg)
        tl = th_w.get("-X" if d == "+X" else "+X", b.roof_angle_deg)
        if b.is_monoslope:
            if tw >= 10.0:
                pair = asce7.cp_windward_roof(hl, tw) if d == "+X" else None
                roof[d] = (f"single plane — windward Cp pair "
                           f"{tuple(_R(c,3) for c in asce7.cp_windward_roof(hl, tw))}"
                           if d == "+X" else
                           f"single plane — leeward Cp "
                           f"{_R(asce7.cp_leeward_roof(hl, tl), 3)}")
            else:
                roof[d] = (f"zoned by x from windward edge: bounds at h="
                           f"{_R(h,2)}, 2h={_R(2*h,2)} → Cp −0.9/−0.5/−0.3"
                           if hl <= 0.5 else
                           f"zoned: bound at h/2={_R(h/2,2)} → Cp −1.3/−0.7")
        elif tw >= 10.0:
            pair = asce7.cp_windward_roof(hl, tw)
            roof[d] = (f"windward slope θ={_R(tw,1)}° → Cp "
                       f"({_R(pair[0],3)} / {_R(pair[1],3)}); leeward slope "
                       f"θ={_R(tl,1)}° → Cp {_R(asce7.cp_leeward_roof(hl, tl),3)}")
        else:
            roof[d] = (f"low slope (θ<10°): zoned by x from windward edge — "
                       f"bounds h={_R(h,2)}, 2h={_R(2*h,2)} → Cp −0.9/−0.5/−0.3"
                       if hl <= 0.5 else
                       f"low slope: bound h/2={_R(h/2,2)} → Cp −1.3/−0.7")
    for d in [y for y in directions if "Y" in y]:
        roof[d] = (f"parallel to ridge: roof zoned by distance from windward "
                   f"gable end (bounds h={_R(h,2)}, 2h={_R(2*h,2)})")
    return {"ratios": ratios, "walls": walls, "roof": roof,
            "GCpi": f"±{w.gcpi} ({w.enclosure}, Table 26.13-1)"}


def _step3_pressures(b: Building, w: WindParams, directions) -> dict:
    """Net design pressures per direction with the row-by-row internal check.

    p = q·Kd·G·Cp − q_h·Kd·(±GCpi)   (Eq 27.3-1)
    p_ext = (p₊ + p₋)/2  ;  p_int = (p₋ − p₊)/2  must equal q_h·Kd·GCpi.
    """
    h = b.mean_roof_height
    qh = asce7.qz(h, w.V, w.exposure, w.units, w.Kzt, w.Ke)
    p_int_expected = qh * w.Kd * w.gcpi
    fi = 1 if b.n_frames > 2 else 0
    out = {"formula": "p = q·Kd·G·Cp − q_h·Kd·(±GCpi)   [Eq 27.3-1]",
           "internal_check": (f"CHECK column: (p[−GCpi] − p[+GCpi])/2 must equal "
                              f"q_h·Kd·GCpi = {_R(qh,2)}·{w.Kd}·{w.gcpi} = "
                              f"{_R(p_int_expected,2)} {w.units.pressure} on every row"),
           "interior_frame": fi, "directions": {}, "all_checks_pass": True}
    for d in directions:
        cases = compute_loads(b, w, direction=d)
        names = list(cases)
        rows: dict = {}
        for cname, members in cases.items():
            for m in members:
                if m.frame != fi:
                    continue
                for si, s in enumerate(m.segments):
                    key = (m.role, s.direction, si)
                    rows.setdefault(key, {"surface": m.role, "axis": s.direction,
                                          "zone": si})
                    rows[key][cname] = s.pressure
        table = []
        for r in rows.values():
            pp, pm = r.get(names[0]), r.get(names[1])
            if pp is None or pm is None:
                continue
            p_ext = (pp + pm) / 2.0
            p_int = (pm - pp) / 2.0
            ok = math.isclose(abs(p_int), p_int_expected, rel_tol=1e-6,
                              abs_tol=1e-6)
            if not ok:
                out["all_checks_pass"] = False
            table.append({"surface": r["surface"], "axis": r["axis"],
                          "zone": r["zone"],
                          "p_plus": _R(pp, 2), "p_minus": _R(pm, 2),
                          "p_ext": _R(p_ext, 2), "p_int": _R(abs(p_int), 2),
                          "CHECK": "OK" if ok else "MISMATCH"})
        out["directions"][d] = {"cases": names, "rows": table}
    return out


def _step4_member_loads(b: Building, w: WindParams, directions) -> dict:
    """Line loads w = p × tributary for every frame/role/segment, per case."""
    out = {"note": ("line load w = net pressure p × tributary width; "
                    "D = relative position along the member (i-end=0)"),
           "tributaries": {str(i): _R(t, 3)
                           for i, t in enumerate(b.tributaries())},
           "directions": {}}
    for d in directions:
        cases = compute_loads(b, w, direction=d)
        dcases = {}
        for cname, members in cases.items():
            rows = []
            for m in members:
                for s in m.segments:
                    rows.append({"frame": str(m.frame), "role": m.role,
                                 "axis": s.direction,
                                 "D": f"{_R(s.d0,3)}–{_R(s.d1,3)}",
                                 "w0": _R(s.w0, 1), "w1": _R(s.w1, 1),
                                 "p": _R(s.pressure, 2)})
            dcases[cname] = rows
        out["directions"][d] = dcases
    return out


def _step5_mwfrs(b: Building, w: WindParams, directions) -> dict:
    """Fig 27.3-8 case set + the relative-base-shear ratio validation table."""
    from .mwfrs import mwfrs_cases
    axes = tuple(directions) if directions else ("+X", "-X", "+Y", "-Y")
    cases = mwfrs_cases(b, w, axes=axes)

    # reference: full wind per axis & GCpi sign (= C1); must also cover the
    # diagonal fallback axes (axes=("+X",) still yields C3/C4 with +Y)
    xs = [d for d in axes if "X" in d] or ["+X"]
    ys = [d for d in axes if "Y" in d] or ["+Y"]
    ref_axes = list(dict.fromkeys(list(axes) + xs + ys))
    ref = {}
    for ax in ref_axes:
        for sign, gp in ((+1, "+GCpi"), (-1, "-GCpi")):
            mem = next(iter(compute_loads(b, w, ax, gcpi_signs=(sign,)).values()))
            axis = "GX" if "X" in ax else "GY"
            ref[(ax, gp)] = _rel_shear(mem, axis)

    e_desc = {
        "±X wind": f"e = {ECCENTRICITY}·B(Y) = {_R(ECCENTRICITY*b.length,3)}",
        "±Y wind": f"e = {ECCENTRICITY}·B(X) = {_R(ECCENTRICITY*b.span,3)}",
    }
    defs = [
        {"case": "C1", "factor": CASE_FACTORS[1],
         "desc": "full design pressures, each principal axis separately"},
        {"case": "C2", "factor": CASE_FACTORS[2],
         "desc": f"75% pressures + torsion M_T (e=±{ECCENTRICITY}B, via "
                 "linear-graded frame loads)"},
        {"case": "C3", "factor": CASE_FACTORS[3],
         "desc": "75% wall pressures on BOTH axes; roof = envelope (Note 2)"},
        {"case": "C4", "factor": CASE_FACTORS[4],
         "desc": "56.25% wall pressures on both axes + torsion; roof envelope"},
    ]

    rows = []
    all_ok = True
    for name, members in cases.items():
        parts = name.split()              # MWFRS C? <dirs> [e±] ±GCpi
        c = int(parts[1][1])
        gp = parts[-1]
        fac = CASE_FACTORS[c]
        checks = []
        if c in (1, 2):
            ax = parts[2]
            axis = "GX" if "X" in ax else "GY"
            got = _rel_shear(members, axis)
            want = fac * ref[(ax, gp)]
            ok = math.isclose(got, want, rel_tol=1e-6, abs_tol=1e-9)
            checks.append((f"Σ{axis} = {fac}×full", ok))
        else:                              # diagonal: both wall axes
            dx, dy = parts[2][:2], parts[2][2:]
            for ax, axis in ((dx, "GX"), (dy, "GY")):
                got = _rel_shear([m for m in members], axis)
                want = fac * ref[(ax, gp)]
                ok = math.isclose(got, want, rel_tol=1e-6, abs_tol=1e-9)
                checks.append((f"Σ{axis} = {fac}×full({ax})", ok))
        ok_all = all(o for _, o in checks)
        if not ok_all:
            all_ok = False
        rows.append({"case": name, "factor": fac,
                     "checks": "; ".join(c for c, _ in checks),
                     "CHECK": "OK" if ok_all else "MISMATCH"})
    return {"reference": "ASCE 7-22 Fig 27.3-8 (Design Wind Load Cases)",
            "eccentricity": e_desc, "definitions": defs,
            "n_cases": len(cases), "rows": rows, "all_checks_pass": all_ok,
            "shear_note": ("relative base shears (w·Δd sums — member lengths "
                           "cancel in the ratios); torsion gradients are "
                           "force-weighted mean 1.0 so ΣF is exactly factor×full")}


def _gravity_section(b: Building, w: WindParams, dead, live) -> dict:
    from .gravity import roof_gravity_cases
    cases = roof_gravity_cases(b, dead, live)
    out = {"note": ("roof gravity as -GZ projected line loads: "
                    "w = pressure × tributary"), "cases": {}}
    for cname, members in cases.items():
        out["cases"][cname] = [
            {"frame": str(m.frame), "role": m.role,
             "w": _R(m.segments[0].w0, 1)} for m in members if m.segments]
    return out


def build_calc_report(building: Building, wind: WindParams, directions,
                      mode: str = "wind", dead: float = 0.0, live: float = 0.0,
                      ridge_azimuth_deg: float = 90.0,
                      meta: dict | None = None) -> dict:
    """Assemble the full step-by-step report dict (pure)."""
    dirs = list(directions) or ["+X"]
    rep = {
        "title": "Wind Load Calculation Report — ASCE 7-22 MWFRS (Directional)",
        "credit": ["Design and Verify by : Peerapat Pinyopojanee, M. Eng",
                   "Powered and Coded by : Claude AI"],
        "disclaimer": ("Provided as-is; developed and verified only by the "
                       "author's own tests (validated against ASCE 7-22 Wind "
                       "Loads Guide Example G3-1). Independent review by a "
                       "licensed engineer is required before production use."),
        "meta": meta or {},
        "inputs": _inputs_section(building, wind, dirs, mode, dead, live,
                                  ridge_azimuth_deg),
        "step1_velocity_pressure": _step1_velocity(building, wind),
        "step2_coefficients": _step2_coefficients(building, wind, dirs),
        "step3_design_pressures": _step3_pressures(building, wind, dirs),
        "step4_member_loads": _step4_member_loads(building, wind, dirs),
    }
    if mode in ("mwfrs", "wind_mwfrs", "full"):
        rep["step5_mwfrs"] = _step5_mwfrs(building, wind, dirs)
    if mode == "full" and (dead or live):
        rep["gravity"] = _gravity_section(building, wind, dead, live)
    checks = [rep["step3_design_pressures"]["all_checks_pass"]]
    if "step5_mwfrs" in rep:
        checks.append(rep["step5_mwfrs"]["all_checks_pass"])
    rep["validation_summary"] = {
        "internal_pressure_rows": "PASS" if checks[0] else "FAIL",
        "mwfrs_shear_ratios": ("PASS" if len(checks) > 1 and checks[1]
                               else ("n/a" if len(checks) == 1 else "FAIL")),
        "all_pass": all(checks),
    }
    return rep
