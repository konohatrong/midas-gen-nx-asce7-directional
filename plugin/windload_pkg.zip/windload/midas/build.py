"""Build gable-frame geometry in GEN NX and return a role->element-id map.

Deterministic numbering (per frame f, 0-indexed):
  nodes    5f+1 base_WW, 5f+2 eave_WW, 5f+3 ridge, 5f+4 eave_LW, 5f+5 base_LW
  elements 4f+1 WWcol,   4f+2 WWroof,  4f+3 LWroof, 4f+4 LWcol
"""
from __future__ import annotations

from ..geometry import Building

# DB tables this tool owns, in dependency-safe delete order
# (GRUP last: clears stale Structure Groups so they don't accumulate / dangle)
_OWNED = ("/db/BMLD", "/db/CONS", "/db/ELEM", "/db/NODE", "/db/SECT", "/db/MATL",
          "/db/GRUP")

# Structure Groups the user assigns elements to (for the "existing model" path).
# The tool reads roles from these names (+ geometry fallback).
#   Roof: tag WWroof + LWroof for a GABLE, or ROOF for a MONOSLOPE — the engine
#   auto-detects the roof shape from geometry (2 roof members/frame = gable,
#   1 = monoslope), so only the matching group(s) need elements.
#   End walls: ENDWALL0 = first gable end (Y min), ENDWALL1 = last (Y max).
TAGGING_GROUPS = ["WWcol", "LWcol", "WWroof", "LWroof", "ROOF",
                  "ENDWALL0", "ENDWALL1", "CORNER"]


def create_tagging_groups(names=None) -> dict:
    """Create the tool's tagging Structure Groups WITHOUT deleting existing ones.

    Reads /db/GRUP, preserves every existing group, and adds only the missing
    tagging groups with fresh IDs, then PUTs the merged set. (midas_gen's
    Group.create() PUTs only its own buffer, which wipes pre-existing project
    groups — not acceptable on a real model.)
    Returns {created, skipped, existing_kept}.
    """
    import midas_gen as mg
    names = names or TAGGING_GROUPS
    existing = mg.MidasAPI("GET", "/db/GRUP").get("GRUP", {})
    present = {v.get("NAME") for v in existing.values()}
    # rebuild existing groups with the canonical schema (keeps name + members)
    assign = {k: {"NAME": v.get("NAME", ""), "P_TYPE": v.get("P_TYPE", 0),
                  "N_LIST": v.get("N_LIST", []), "E_LIST": v.get("E_LIST", [])}
              for k, v in existing.items()}
    next_id = max((int(k) for k in existing), default=0) + 1
    created, skipped = [], []
    for nm in names:
        if nm in present:
            skipped.append(nm)
            continue
        assign[str(next_id)] = {"NAME": nm, "P_TYPE": 0,
                                "N_LIST": [], "E_LIST": []}
        present.add(nm)
        created.append(nm)
        next_id += 1
    if created:
        mg.MidasAPI("PUT", "/db/GRUP", {"Assign": assign})
    return {"created": created, "skipped": skipped,
            "existing_kept": len(existing)}


def clear_model() -> None:
    import midas_gen as mg
    for tbl in _OWNED:
        mg.MidasAPI("DELETE", tbl)
    mg.Model.clear()


def build_geometry(b: Building,
                   material=("A992", "ASTM(S)", "A992"),
                   section=("W8x35", "H", "AISC", "W8x35"),
                   base_support="pin") -> dict:
    """Create + push material, section, nodes, elements, supports, groups.

    Builds the geometry in the midas_gen buffers and pushes it with
    Model.create() (loads are pushed separately by push_loads via raw JSON).
    Returns {(frame, role): element_id}.
    """
    import midas_gen as mg
    mg.Material.STEEL(*material)
    mg.Section.DB(*section, id=1)

    role_map: dict = {}
    # windward-eave X per frame follows the taper alignment (center/windward/leeward);
    # for a uniform building this is 0 -> windward eave at X=0 (unchanged layout).
    # merge=False everywhere: never let coincident nodes merge away (would break
    # an element's node reference -> 'NoneType' has no attribute 'X').
    if b.is_monoslope:
        npf, epf = 4, 3                          # nodes / elements per frame
        for f, y in enumerate(b.frame_positions):
            n, e = npf * f, epf * f
            s, x_ww = b.span_at(f), b.windward_eave_x_at(f)
            mg.Node(x_ww, y, 0, id=n + 1, merge=False)               # base low
            mg.Node(x_ww, y, b.eave_at(f), id=n + 2, merge=False)    # eave low
            mg.Node(x_ww + s, y, b.ridge_height_at(f), id=n + 3, merge=False)  # high
            mg.Node(x_ww + s, y, 0, id=n + 4, merge=False)          # base high
            mg.Element.Beam(n + 1, n + 2, mat=1, sect=1, group="WWcol", id=e + 1)
            mg.Element.Beam(n + 2, n + 3, mat=1, sect=1, group="ROOF", id=e + 2)
            mg.Element.Beam(n + 4, n + 3, mat=1, sect=1, group="LWcol", id=e + 3)
            mg.Boundary.Support(n + 1, base_support)
            mg.Boundary.Support(n + 4, base_support)
            role_map[(f, "WWcol")] = e + 1
            role_map[(f, "ROOF")] = e + 2
            role_map[(f, "LWcol")] = e + 3
    else:
        npf, epf = 5, 4
        for f, y in enumerate(b.frame_positions):
            n, e = npf * f, epf * f
            s, x_ww = b.span_at(f), b.windward_eave_x_at(f)   # per-frame span + align
            y_lw = b.y_at(f, leeward=True)                    # leeward column Y (skew)
            rx = b.ridge_x_at(f)
            y_ridge = y + (rx / s) * (y_lw - y) if s else y   # ridge Y interpolated
            mg.Node(x_ww, y, 0, id=n + 1, merge=False)
            mg.Node(x_ww, y, b.eave_at(f), id=n + 2, merge=False)
            mg.Node(x_ww + rx, y_ridge, b.ridge_height_at(f),
                    id=n + 3, merge=False)                  # ridge (offset/taper/skew)
            mg.Node(x_ww + s, y_lw, b.eave_at(f), id=n + 4, merge=False)
            mg.Node(x_ww + s, y_lw, 0, id=n + 5, merge=False)
            mg.Element.Beam(n + 1, n + 2, mat=1, sect=1, group="WWcol", id=e + 1)
            mg.Element.Beam(n + 2, n + 3, mat=1, sect=1, group="WWroof", id=e + 2)
            mg.Element.Beam(n + 3, n + 4, mat=1, sect=1, group="LWroof", id=e + 3)
            mg.Element.Beam(n + 4, n + 5, mat=1, sect=1, group="LWcol", id=e + 4)
            mg.Boundary.Support(n + 1, base_support)
            mg.Boundary.Support(n + 5, base_support)
            role_map[(f, "WWcol")] = e + 1
            role_map[(f, "WWroof")] = e + 2
            role_map[(f, "LWroof")] = e + 3
            role_map[(f, "LWcol")] = e + 4

    # CORNER group: the 4 end-frame columns (resist both wind directions)
    corner_ids = []
    for f in (0, b.n_frames - 1):
        corner_ids += [role_map[(f, "WWcol")], role_map[(f, "LWcol")]]
    mg.Group.Structure("CORNER", elist=sorted(set(corner_ids)))

    # gable-end wind posts (after the frame ids). ep.x is local to that end's
    # windward eave; shift by the centered offset for that end's span (taper).
    nid, eid = npf * b.n_frames, epf * b.n_frames
    for ep in b.end_posts():
        ef = 0 if ep.end_idx == 0 else b.n_frames - 1
        x_abs = b.windward_eave_x_at(ef) + ep.x
        nid += 1
        base = nid
        mg.Node(x_abs, ep.y, 0, id=base, merge=False)
        nid += 1
        top = nid
        mg.Node(x_abs, ep.y, ep.height, id=top, merge=False)
        eid += 1
        mg.Element.Beam(base, top, mat=1, sect=1,
                        group=f"ENDWALL{ep.end_idx}", id=eid)
        mg.Boundary.Support(base, base_support)
        role_map[(f"END{ep.end_idx}", f"post{ep.post_idx}")] = eid

    mg.Model.create()          # push geometry (push_loads pushes loads separately)
    return role_map
