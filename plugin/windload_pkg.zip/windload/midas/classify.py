"""Reconstruct a Building + member roles from a pulled MIDAS model.

Works on *logical members* (collinear element chains from members.group_members),
so a member meshed into several elements is treated as one. Detects roof type
(gable vs monoslope) from the per-frame roof-member count. Roles are POSITIONAL
(WWcol = min-X column, LWcol = max-X column, etc.); compute_loads applies the
aerodynamic windward/leeward by wind direction. role_map values are oriented
`Member` objects so push can distribute loads across the (meshed) pieces.

Roles come from Structure Group names when they encode them, else from geometry
(vertical = column, sloped = roof). Produces a verification report (the extract ->
verify gate, #9) the user reviews before computing loads. Pure (no MIDAS).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..geometry import Building, EndPost
from .pull import RawModel
from .members import group_members, orient, Member


@dataclass
class PullReport:
    n_frames: int
    frame_positions: list
    span: float
    eave_height: float
    ridge_height: float
    roof_angle_deg: float
    tributaries: list
    role_counts: dict
    roof_type: str = "gable"
    roof_angle_deg2: float | None = None     # right slope for unequal-pitch gable
    end_posts: int = 0
    meshed_members: int = 0
    end_posts_detail: list = field(default_factory=list)  # verify-gate: real posts
    #   [{end, post, x, height, tributary}] resolved from the tagged geometry
    frames_detail: list = field(default_factory=list)  # verify-gate: per-frame
    #   measurements [{frame, y_ww, y_lw, span, eave, x_ww}] — what #perframe
    #   recovery read from the model (taper / stepped eave / wall line)
    warnings: list = field(default_factory=list)   # things to verify
    notes: list = field(default_factory=list)      # informational (not problems)


@dataclass
class PulledModel:
    building: Building
    role_map: dict          # {(frame_index, role): Member}
    report: PullReport
    raw: RawModel


def _role_from_group(names: set) -> tuple:
    """(kind, side) from group names. kind in {'column','roof'}; side in
    {'windward','leeward',None}."""
    low = " ".join(names).lower()
    if "wwcol" in low:
        return ("column", "windward")
    if "lwcol" in low:
        return ("column", "leeward")
    if "wwroof" in low:
        return ("roof", "windward")
    if "lwroof" in low:
        return ("roof", "leeward")
    if "corner" in low or "col" in low or "wall" in low:
        return ("column", None)
    if "roof" in low or "rafter" in low:
        return ("roof", None)
    return (None, None)


def _orientation(ci, cj):
    dz = abs(cj[2] - ci[2])
    dxy = math.hypot(cj[0] - ci[0], cj[1] - ci[1])
    return "column" if dz > dxy else "roof"


def _median(xs):
    if not xs:
        return 0.0
    s = sorted(xs)
    n = len(s)
    return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2


def reconstruct(raw: RawModel, wind: str = "+X", y_tol: float = 1e-3) -> PulledModel:
    """wind is accepted for API compatibility but no longer affects role
    assignment (roles are positional; compute_loads handles direction)."""
    members = group_members(raw)
    elem_to_groups: dict = {}
    for gname, eids in raw.groups.items():
        for e in eids:
            elem_to_groups.setdefault(e, set()).add(gname)

    # describe each logical member
    descs = []
    meshed = 0
    for mem in members:
        if len(mem.element_ids) > 1:
            meshed += 1
        gnames: set = set()
        for e in mem.element_ids:
            gnames |= elem_to_groups.get(e, set())
        co = mem.coords
        xs = [c[0] for c in co]
        zs = [c[2] for c in co]
        kind, side = _role_from_group(gnames)
        is_post = any("endwall" in n.lower() or "epost" in n.lower()
                      for n in gnames)
        tagged = (kind is not None) or is_post     # explicitly placed in a group
        if kind is None and not is_post:
            kind = _orientation(co[0], co[-1])      # geometry guess (fallback only)
        dx = max(xs) - min(xs)
        angle = math.degrees(math.atan2(max(zs) - min(zs), dx)) if dx > 1e-9 else 90.0
        descs.append(dict(
            mem=mem, gnames=gnames, side=side, kind=kind, is_post=is_post,
            tagged=tagged,
            meanx=sum(xs) / len(xs), meany=sum(c[1] for c in co) / len(co),
            topz=max(c[2] for c in co), minx=min(xs), maxx=max(xs), angle=angle))

    # If the model uses tags, load ONLY tagged elements — don't let the geometry
    # fallback classify (and load) ungrouped beams (floor beams, bracing, etc.).
    # The fallback applies only to fully-untagged models.
    tags_present = any(d["tagged"] for d in descs)

    # Group members into FRAMES by CONNECTIVITY (shared nodes), NOT by Y: a frame's
    # column-rafter-rafter-column chain is connected, while different frames are not
    # — so windward & leeward columns pair up even when SKEWED (different Y).
    used = [d for d in descs if not d["is_post"]
            and (not tags_present or d["tagged"])
            and d["kind"] in ("column", "roof")]
    if not used:
        raise ValueError(
            "No frame elements found. Open a gable/monoslope model (or generate "
            "one), tag walls/roof in Structure Groups; the model appears empty or "
            "has no beam elements.")
    parent = list(range(len(used)))

    def _find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    node_to_idx: dict = {}
    for idx, d in enumerate(used):
        for n in d["mem"].node_ids:
            node_to_idx.setdefault(n, []).append(idx)
    for idxs in node_to_idx.values():
        for k in range(1, len(idxs)):
            parent[_find(idxs[k])] = _find(idxs[0])
    comps: dict = {}
    for idx in range(len(used)):
        comps.setdefault(_find(idx), []).append(idx)

    def _ww_y(members_idx):           # windward-column Y (orders frames; skew-safe)
        cols = sorted((used[i] for i in members_idx if used[i]["kind"] == "column"),
                      key=lambda d: d["meanx"])
        if cols:
            return cols[0]["meany"]
        ys = [used[i]["meany"] for i in members_idx]
        return sum(ys) / len(ys)

    ordered = sorted(comps.values(), key=_ww_y)
    frame_ys = [_ww_y(m) for m in ordered]
    per_frame = {fi: {"column": [], "roof": []} for fi in range(len(ordered))}
    for fi, members_idx in enumerate(ordered):
        for i in members_idx:
            per_frame[fi][used[i]["kind"]].append(used[i])
    posts = [d for d in descs if d["is_post"]]
    ignored_untagged = sum(1 for d in descs if not d["is_post"]
                           and d["kind"] in ("column", "roof")
                           and tags_present and not d["tagged"])

    # roof type: gable has 2 roof members per frame, monoslope has 1
    roof_counts = [len(per_frame[i]["roof"]) for i in range(len(frame_ys))]
    roof_type = "gable" if _median(roof_counts) >= 2 else "monoslope"

    role_map: dict = {}
    warnings: list = []
    notes: list = []
    spans, col_tops, left_ang, right_ang = [], [], [], []
    frame_eaves, frame_wwx, frame_high = [], [], []   # per-frame recovery (#perframe)
    frame_apex_x, frame_apex_z = [], []               # measured ridge apex per frame
    ww_y_list, lw_y_list = [], []     # windward/leeward column Y per frame (skew)
    for fi, kinds in per_frame.items():
        cols = sorted(kinds["column"], key=lambda d: d["meanx"])
        roofs = sorted(kinds["roof"], key=lambda d: d["meanx"])
        ww_y_list.append(cols[0]["meany"] if cols else frame_ys[fi])
        lw_y_list.append(cols[-1]["meany"] if cols else frame_ys[fi])
        if roof_type == "gable" and len(roofs) >= 2:
            left_ang.append(roofs[0]["angle"])    # X=0 side slope
            right_ang.append(roofs[-1]["angle"])  # X=span side slope
        exp_roofs = 2 if roof_type == "gable" else 1
        if len(cols) != 2 or len(roofs) != exp_roofs:
            warnings.append(f"frame {fi}: expected 2 columns + {exp_roofs} "
                            f"roof(s), got {len(cols)}/{len(roofs)}")
        if len(cols) >= 1:
            role_map[(fi, "WWcol")] = orient(cols[0]["mem"], raw.elements, "z")
        if len(cols) >= 2:
            role_map[(fi, "LWcol")] = orient(cols[-1]["mem"], raw.elements, "z")
        if roof_type == "monoslope":
            if roofs:
                role_map[(fi, "ROOF")] = orient(roofs[0]["mem"], raw.elements, "x")
        else:
            if len(roofs) >= 1:
                role_map[(fi, "WWroof")] = orient(roofs[0]["mem"],
                                                  raw.elements, "x")
            if len(roofs) >= 2:
                role_map[(fi, "LWroof")] = orient(roofs[-1]["mem"],
                                                  raw.elements, "x")
        xs = [v for d in cols + roofs for v in (d["minx"], d["maxx"])]
        spans.append(max(xs) - min(xs) if xs else None)
        frame_wwx.append(min(xs) if xs else None)
        ax = az = None                       # ridge apex = highest roof node
        for d in roofs:
            for c in d["mem"].coords:
                if az is None or c[2] > az:
                    az, ax = c[2], c[0]
        frame_apex_x.append(ax)
        frame_apex_z.append(az)
        tops = [d["topz"] for d in cols]
        col_tops += tops
        if roof_type == "monoslope":
            frame_eaves.append(min(tops) if tops else None)
            frame_high.append(max(tops) if tops else None)
        else:
            frame_eaves.append(sum(tops) / len(tops) if tops else None)
            if len(tops) == 2 and abs(tops[0] - tops[1]) > max(
                    0.01 * max(tops), 1e-6):
                warnings.append(
                    f"frame {fi}: windward/leeward eave heights differ "
                    f"({tops[0]:.3f} vs {tops[1]:.3f}) — the engine assumes "
                    f"level eaves per frame; their mean is used")

    # end posts -> (END{end}, post{p}); group by end, order by X. Capture each
    # post's REAL geometry (x, y, top z) so loads follow the actual layout, not an
    # idealized even spacing (#3). post_idx here matches posts_with_tributaries.
    n_end_posts = 0
    raw_posts: list = []
    if posts:
        y_lo, y_hi = frame_ys[0], frame_ys[-1]
        ends = {0: [], 1: []}
        for d in posts:
            end = 0 if abs(d["meany"] - y_lo) <= abs(d["meany"] - y_hi) else 1
            ends[end].append(d)
        counts = []
        for e, plist in ends.items():
            plist.sort(key=lambda d: d["meanx"])
            counts.append(len(plist))
            for p, d in enumerate(plist, start=1):
                role_map[(f"END{e}", f"post{p}")] = orient(
                    d["mem"], raw.elements, "z")
                raw_posts.append(EndPost(e, p, d["meanx"], d["meany"],
                                         d["topz"], 0.0))   # trib filled below
        n_end_posts = max(counts) if counts else 0
        if len(set(counts)) > 1:
            warnings.append(f"end posts per end differ: {counts}")

    # --- per-frame recovery (#perframe): real measured values per frame win over
    #     the median idealization (taper / stepped eave / non-straight wall). A
    #     uniform building still collapses to the plain scalars (no noise). ---
    def _fill(vals):
        """Replace None gaps with the median of the known values."""
        known = [v for v in vals if v is not None]
        med = _median(known)
        return [med if v is None else v for v in vals], med

    spans, span = _fill(spans)
    frame_wwx, wwx_med = _fill(frame_wwx)
    frame_eaves, eave_med = _fill(frame_eaves)

    def _varies(vals, ref, tol=0.01):
        return (len(vals) > 1
                and max(vals) - min(vals) > max(tol * abs(ref), 1e-6))

    span_list = list(spans) if _varies(spans, span) else None
    eaves_list = list(frame_eaves) if _varies(frame_eaves, eave_med) else None
    # the wall LINE is stored whenever the span varies (not only when the
    # windward X moves): a pulled Building has no taper_ref, so without the
    # measured line it would default to a CENTER splay and misplace both walls.
    wwx_list = (list(frame_wwx)
                if (span_list is not None or _varies(frame_wwx, span))
                else None)
    if span_list:
        notes.append(f"per-frame spans recovered (tapered): "
                     f"{min(spans):.2f} -> {max(spans):.2f}")
    if eaves_list:
        notes.append(f"per-frame eave heights recovered: "
                     f"{min(frame_eaves):.2f} -> {max(frame_eaves):.2f}")
    if wwx_list:
        notes.append("windward wall line recovered (non-straight alignment): "
                     f"X {min(frame_wwx):.2f} -> {max(frame_wwx):.2f}")

    theta2 = None
    ridge_x_list = ridge_z_list = None      # measured per-frame ridge (#perframe)
    if roof_type == "monoslope":
        eave = eave_med
        ridge = max(v for v in frame_high if v is not None) if any(
            v is not None for v in frame_high) else eave
        # per-frame theta (taper-aware): rise_i / span_i, median across frames
        thetas = [math.degrees(math.atan2(max(h - e, 0.0), s))
                  for h, e, s in zip(frame_high, frame_eaves, spans)
                  if h is not None and s]
        theta = _median(thetas) if thetas else 0.0
        if thetas and max(thetas) - min(thetas) > 1.0:
            if all(v is not None for v in frame_high):
                # heights recovered exactly (q_h, wall heights, longitudinal
                # tops); only the roof Cp still uses the median angle.
                ridge_z_list = list(frame_high)
                notes.append(f"per-frame high-eave heights recovered: "
                             f"{min(frame_high):.2f} -> {max(frame_high):.2f}")
            warnings.append(
                f"monoslope roof angle varies per frame "
                f"({min(thetas):.1f}-{max(thetas):.1f} deg); roof Cp uses the "
                f"median angle")
    else:
        eave = eave_med
        roof_tops = [d["topz"] for i in per_frame for d in per_frame[i]["roof"]]
        ridge = max(roof_tops) if roof_tops else eave
        # per-plane angles from the actual rafter geometry (unequal pitch)
        al = _median(left_ang) if left_ang else 0.0
        ar = _median(right_ang) if right_ang else 0.0
        varying = [side for side, angs in (("left", left_ang),
                                           ("right", right_ang))
                   if angs and max(angs) - min(angs) > 0.5]
        if varying:
            if (all(a is not None for a in frame_apex_x)
                    and all(z is not None for z in frame_apex_z)):
                # measured ridge apex per frame -> angle_*_at derive each
                # frame's REAL pitches (ridge-aligned taper recovered exactly)
                ridge_x_list = [a - w for a, w in zip(frame_apex_x, frame_wwx)]
                ridge_z_list = list(frame_apex_z)
                notes.append(
                    f"per-frame ridge recovered (varying pitch): left "
                    f"{min(left_ang):.1f}-{max(left_ang):.1f} deg, right "
                    f"{min(right_ang):.1f}-{max(right_ang):.1f} deg")
            else:
                warnings.append(
                    f"roof pitch varies per frame ({'/'.join(varying)}) but "
                    f"the ridge apex could not be measured on every frame; "
                    f"median angles used")
        if left_ang and right_ang and abs(al - ar) > 0.5:   # asymmetric (>0.5 deg)
            theta, theta2 = al, ar
        elif left_ang or right_ang:
            theta = al if not right_ang else (ar if not left_ang else (al + ar) / 2)
        else:                                                # fallback: from rise
            theta = math.degrees(math.atan2(max(ridge - eave, 0.0),
                                            span / 2)) if span else 0.0

    # fill post tributaries from ACTUAL spacing (corners at X=0 and X=span_e
    # bound each end, per-end span on a taper); post x is measured from that
    # end's windward eave so it matches the generation convention.
    explicit_posts = None
    if raw_posts:
        raw_posts = [EndPost(ep.end_idx, ep.post_idx,
                             ep.x - frame_wwx[0 if ep.end_idx == 0 else -1],
                             ep.y, ep.height, 0.0) for ep in raw_posts]
        explicit_posts = Building.posts_with_tributaries(
            span, raw_posts, span_by_end={0: spans[0], 1: spans[-1]})

    # recover skewed frames: windward vs leeward column Y differ -> capture both
    skewed = any(abs(a - b) > 1e-3 for a, b in zip(ww_y_list, lw_y_list))
    building = Building(frame_positions=list(ww_y_list), span=span,
                        eave_height=eave, roof_angle_deg=theta,
                        roof_angle_deg2=theta2, roof_type=roof_type,
                        n_end_posts=n_end_posts,
                        frame_positions_leeward=(list(lw_y_list) if skewed else None),
                        explicit_end_posts=explicit_posts,
                        span_per_frame=span_list, eave_heights=eaves_list,
                        wall_x_windward=wwx_list,
                        ridge_x_per_frame=ridge_x_list,
                        ridge_z_per_frame=ridge_z_list)

    role_names = (("WWcol", "LWcol", "ROOF") if roof_type == "monoslope"
                  else ("WWcol", "LWcol", "WWroof", "LWroof"))
    for r in role_names:
        n = sum(1 for k in role_map if k[1] == r)
        if n != len(frame_ys):
            warnings.append(f"role {r}: found on {n}/{len(frame_ys)} frames")
    if ignored_untagged:
        notes.append(f"tag mode: loads applied to TAGGED elements only — "
                     f"{ignored_untagged} ungrouped member(s) ignored")

    post_detail = [{"end": ep.end_idx, "post": ep.post_idx,
                    "x": round(ep.x, 4), "height": round(ep.height, 4),
                    "tributary": round(ep.tributary, 4)}
                   for ep in (explicit_posts or [])]
    def _r(v):
        return None if v is None else round(v, 4)

    frames_detail = [{"frame": i, "y_ww": round(ww_y_list[i], 4),
                      "y_lw": round(lw_y_list[i], 4),
                      "span": round(spans[i], 4),
                      "eave": round(frame_eaves[i], 4),
                      "x_ww": round(frame_wwx[i], 4),
                      "ridge_x": _r(None if frame_apex_x[i] is None
                                    else frame_apex_x[i] - frame_wwx[i]),
                      "ridge_z": _r(frame_apex_z[i])}
                     for i in range(len(frame_ys))]

    report = PullReport(
        n_frames=len(frame_ys), frame_positions=list(frame_ys), span=span,
        eave_height=eave, ridge_height=ridge, roof_angle_deg=theta,
        roof_angle_deg2=theta2,
        tributaries=building.tributaries(), roof_type=roof_type,
        role_counts={r: sum(1 for k in role_map if k[1] == r)
                     for r in role_names},
        end_posts=n_end_posts, meshed_members=meshed,
        end_posts_detail=post_detail, frames_detail=frames_detail,
        warnings=warnings, notes=notes)
    return PulledModel(building=building, role_map=role_map, report=report,
                       raw=raw)
