"""Read geometry from MIDAS GEN NX into plain Python (the 'pull' half of Phase 3).

read_model() does the live GET calls; parse_model() is pure (parses the JSON the
GETs return, so it is unit-testable from a fixture).
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class RawModel:
    nodes: dict          # {id(int): (x, y, z)}
    elements: dict       # {id(int): (i_node, j_node)}  (beam i->j)
    groups: dict         # {name(str): set(element_id)}


def parse_model(node_json: dict, elem_json: dict, grup_json: dict) -> RawModel:
    nodes = {int(i): (v["X"], v["Y"], v["Z"]) for i, v in node_json.items()}
    elements = {}
    for i, v in elem_json.items():
        nl = v.get("NODE", [])
        if v.get("TYPE") == "BEAM" and len(nl) >= 2:
            elements[int(i)] = (int(nl[0]), int(nl[1]))
    groups = {}
    for v in grup_json.values():
        name = v.get("NAME", "")
        elist = {int(e) for e in v.get("E_LIST", [])}
        if name:
            groups.setdefault(name, set()).update(elist)
    return RawModel(nodes=nodes, elements=elements, groups=groups)


def read_model() -> RawModel:
    """Live pull of /db/NODE, /db/ELEM, /db/GRUP from the connected GEN NX."""
    import midas_gen as mg
    nd = mg.MidasAPI("GET", "/db/NODE").get("NODE", {})
    el = mg.MidasAPI("GET", "/db/ELEM").get("ELEM", {})
    gr = mg.MidasAPI("GET", "/db/GRUP").get("GRUP", {})
    return parse_model(nd, el, gr)
