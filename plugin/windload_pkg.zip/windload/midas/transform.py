"""World <-> building-local transform for arbitrarily placed/rotated models.

The compute core works in BUILDING-LOCAL axes: X = across the frame (span,
windward -> leeward), Y = along the ridge, Z = up, base at Z = 0. A real project
model can sit anywhere and point anywhere, so the pull path transforms world ->
local before `reconstruct`, and the push decomposes local-axis loads back into
world GX/GY components.

Orientation is USER-DEFINED (no auto-detect — one FEA model may hold several
buildings): `ridge_azimuth_deg` is the RIDGE direction measured from global +X,
CCW positive. Presets 0 (ridge along X) and 90 (ridge along Y = the default,
identical to historical behavior); any other angle (e.g. 33.2) is allowed.

The ORIGIN is AUTO-DETECTED: after rotating into local axes the minimum local
x/y/z are subtracted, so the model may sit anywhere in plan and on a podium
(base Z != 0) — heights are measured from the building's own base.

Local axes for azimuth t:  localY (ridge) = (cos t, sin t, 0),
localX (span) = (sin t, -cos t, 0)  (right-handed with Z up).
Pure — no midas_gen, no HTTP.
"""
from __future__ import annotations

import math

from .pull import RawModel

# GUI/select presets; anything else is a free angle in degrees from +X, CCW+.
ORIENT_PRESETS = [(0.0, "0 deg — ridge along global X"),
                  (90.0, "90 deg — ridge along global Y (default)")]


def to_local(raw: RawModel, ridge_azimuth_deg: float = 90.0):
    """Rotate + shift the pulled world geometry into building-local axes.

    Returns (local RawModel, info) where info records the transform applied:
    {ridge_azimuth_deg, base_z, plan_shift:(x0,y0), origin_world:(x,y,z)} —
    base_z/origin_world are in WORLD coordinates for the verify report.
    """
    t = math.radians(ridge_azimuth_deg)
    c, s = math.cos(t), math.sin(t)
    rot = {nid: (x * s - y * c, x * c + y * s, z)
           for nid, (x, y, z) in raw.nodes.items()}
    if rot:
        x0 = min(p[0] for p in rot.values())
        y0 = min(p[1] for p in rot.values())
        z0 = min(p[2] for p in rot.values())
    else:
        x0 = y0 = z0 = 0.0
    nodes = {nid: (x - x0, y - y0, z - z0) for nid, (x, y, z) in rot.items()}
    # local-frame origin back in world coords (for the report)
    origin_world = (x0 * s + y0 * c, -x0 * c + y0 * s, z0)
    info = {"ridge_azimuth_deg": ridge_azimuth_deg, "base_z": z0,
            "plan_shift": (x0, y0), "origin_world": origin_world}
    return RawModel(nodes=nodes, elements=raw.elements, groups=raw.groups), info


def world_components(direction: str, w0: float, w1: float,
                     ridge_azimuth_deg: float = 90.0) -> list:
    """Decompose a LOCAL-axis load into WORLD global components for /db/BMLD.

    Local GX/GY become up to two world items [(\"GX\"|\"GY\", w0, w1), ...] whose
    vector sum equals the local load (exact; MIDAS sums coincident items). GZ
    (gravity) and local (L*) directions pass through. Azimuth 90 = identity.
    """
    if direction not in ("GX", "GY"):
        return [(direction, w0, w1)]
    t = math.radians(ridge_azimuth_deg)
    c, s = math.cos(t), math.sin(t)
    if direction == "GX":            # local X (span direction) in world
        comps = (("GX", s), ("GY", -c))
    else:                            # local Y (ridge direction) in world
        comps = (("GX", c), ("GY", s))
    return [(d, w0 * f, w1 * f) for d, f in comps if abs(f) > 1e-12]
