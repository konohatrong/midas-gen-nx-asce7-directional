"""Group collinear element chains into logical members, and distribute a member's
load profile across its (possibly meshed) pieces.

Real models often have a single physical member (column/rafter) **meshed** into
several collinear beam elements, because other elements (bracing, posts, purlins,
beams not in the wind system) frame in at intermediate nodes. The wind engine
computes one load profile per *member* (D in 0..1 over the whole member); this
module maps that profile onto the actual elements.

Pure (no MIDAS); unit-tested.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from .pull import RawModel


@dataclass
class RawMember:
    element_ids: list   # ordered end-to-end (geometry order from _order_chain)
    node_ids: list      # ordered, len = len(element_ids)+1
    coords: list        # node coords (x,y,z) in node order


@dataclass
class Member:
    """A logical member oriented so D=0 is a chosen end. Maps member-relative
    load segments (D in 0..1 over the whole member) to per-element BMLD."""
    element_ids: list   # ordered, D=0 end first
    fracs: list         # cumulative length fraction at each node (0..1)
    aligned: list       # per element: True if its i->j matches D=0->1 direction

    def distribute(self, segments):
        """segments: iterable of (d0, d1, w0, w1) in member-relative D (0..1),
        line load ramping w0->w1. Yields (eid, [d0,d1], [w0,w1]) per element,
        each D re-normalised to that element's own i->j (0..1)."""
        out = []
        for k, eid in enumerate(self.element_ids):
            fa, fb = self.fracs[k], self.fracs[k + 1]
            span = (fb - fa) or 1.0
            for d0, d1, w0, w1 in segments:
                lo, hi = max(d0, fa), min(d1, fb)
                if hi - lo <= 1e-9:
                    continue
                dd = (d1 - d0) or 1.0
                wlo = w0 + (w1 - w0) * ((lo - d0) / dd)
                whi = w0 + (w1 - w0) * ((hi - d0) / dd)
                ea, eb = (lo - fa) / span, (hi - fa) / span
                if self.aligned[k]:
                    out.append((eid, [ea, eb], [wlo, whi]))
                else:                       # element runs opposite the member
                    out.append((eid, [1 - eb, 1 - ea], [whi, wlo]))
        return out


def _unit(a, b):
    v = (b[0] - a[0], b[1] - a[1], b[2] - a[2])
    n = math.sqrt(sum(c * c for c in v)) or 1.0
    return (v[0] / n, v[1] / n, v[2] / n)


def _parallel(d1, d2, tol=1e-3):
    cx = d1[1] * d2[2] - d1[2] * d2[1]
    cy = d1[2] * d2[0] - d1[0] * d2[2]
    cz = d1[0] * d2[1] - d1[1] * d2[0]
    return math.sqrt(cx * cx + cy * cy + cz * cz) < tol


def _order_chain(eids, elements):
    """Order a set of collinear, end-to-end connected elements into a path."""
    inc: dict = {}
    for e in eids:
        ni, nj = elements[e]
        inc.setdefault(ni, []).append(e)
        inc.setdefault(nj, []).append(e)
    ends = sorted(n for n, es in inc.items() if len(es) == 1)
    start = ends[0] if ends else sorted(inc)[0]      # deterministic
    node_order, elem_order, used = [start], [], set()
    cur = start
    while True:
        nxt = next((e for e in inc[cur] if e not in used), None)
        if nxt is None:
            break
        used.add(nxt)
        ni, nj = elements[nxt]
        other = nj if ni == cur else ni
        elem_order.append(nxt)
        node_order.append(other)
        cur = other
    return elem_order, node_order


def group_members(raw: RawModel) -> list[RawMember]:
    """Collapse collinear, connected beam elements into logical members."""
    elements, nodes = raw.elements, raw.nodes
    valid = {e: (ni, nj) for e, (ni, nj) in elements.items()
             if ni in nodes and nj in nodes}
    dirs = {e: _unit(nodes[ni], nodes[nj]) for e, (ni, nj) in valid.items()}

    node_elems: dict = {}
    for e, (ni, nj) in valid.items():
        node_elems.setdefault(ni, []).append(e)
        node_elems.setdefault(nj, []).append(e)

    parent = {e: e for e in valid}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for es in node_elems.values():
        for i in range(len(es)):
            for j in range(i + 1, len(es)):
                if _parallel(dirs[es[i]], dirs[es[j]]):
                    parent[find(es[i])] = find(es[j])

    chains: dict = {}
    for e in valid:
        chains.setdefault(find(e), []).append(e)

    members = []
    for es in chains.values():
        elem_order, node_order = _order_chain(es, valid)
        members.append(RawMember(
            element_ids=elem_order, node_ids=node_order,
            coords=[nodes[n] for n in node_order]))
    return members


def orient(rawm: RawMember, elements: dict, axis: str) -> Member:
    """Orient a member so D=0 is at the end with the smaller `axis` coord
    ('z' for columns/posts -> base first; 'x' for roofs -> windward edge first)."""
    idx = {"x": 0, "y": 1, "z": 2}[axis]
    eids, nids, co = (list(rawm.element_ids), list(rawm.node_ids),
                      list(rawm.coords))
    if co[0][idx] > co[-1][idx]:
        eids.reverse(); nids.reverse(); co.reverse()
    seglen = [math.dist(co[k], co[k + 1]) for k in range(len(eids))]
    total = sum(seglen) or 1.0
    fracs = [0.0]
    for L in seglen:
        fracs.append(fracs[-1] + L / total)
    aligned = [elements[e] == (nids[k], nids[k + 1]) for k, e in enumerate(eids)]
    return Member(element_ids=eids, fracs=fracs, aligned=aligned)
