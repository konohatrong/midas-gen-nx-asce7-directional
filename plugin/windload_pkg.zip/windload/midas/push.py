"""Push computed MemberLoads into GEN NX as raw /db/STLD + /db/LDGR + /db/BMLD.

The JSON is built by the pure helpers in payload.py (shared with the Pyodide
plug-in); this module only adds the live HTTP (read units + existing tables,
then PUT). Deterministic and buffer-free — no midas_gen class-buffer leakage.
"""
from __future__ import annotations

from ..units import UnitSystem
from .payload import (bmld_payload, stld_payload, ldgr_payload, bmld_item_count,
                      merge_bmld)


def read_model_units(mg) -> tuple[str, str]:
    """(FORCE, DIST) of the open model, e.g. ('KN','M'). Defaults to kN,m."""
    unit = mg.MidasAPI("GET", "/db/UNIT").get("UNIT", {})
    if not unit:
        return "KN", "M"
    first = next(iter(unit.values()))
    return first.get("FORCE", "KN"), first.get("DIST", "M")


# A single PUT /db/BMLD silently fails past a payload size (seen ~> a few thousand
# items, e.g. a meshed model x the 48-case MWFRS set). Chunk by item count so each
# PUT stays well within limits. PUT is per-element-keyed, so chunking by element is
# safe (each element appears in exactly one chunk).
_BMLD_MAX_ITEMS = 1500


def put_bmld_chunked(mg, assign: dict, max_items: int = _BMLD_MAX_ITEMS) -> int:
    """PUT /db/BMLD in batches; returns the number of items written."""
    batch: dict = {}
    count = 0
    written = 0
    for eid, entry in assign.items():
        n = len(entry.get("ITEMS", []))
        if count and count + n > max_items:
            mg.MidasAPI("PUT", "/db/BMLD", {"Assign": batch})
            written += count
            batch, count = {}, 0
        batch[eid] = entry
        count += n
    if batch:
        mg.MidasAPI("PUT", "/db/BMLD", {"Assign": batch})
        written += count
    return written


def push_loads(cases: dict, role_map: dict, units: UnitSystem,
               use_load_groups: bool = True, case_types: dict | None = None,
               ridge_azimuth_deg: float = 90.0) -> int:
    """Create load cases (+ load groups) and beam loads, via raw /db tables.

    case_types {name: 'D'|'L'|...} sets non-wind static-case types (default 'W').
    ridge_azimuth_deg: building orientation (ridge from +X, CCW+); at != 90 the
    horizontal loads are decomposed into world GX + GY components.
    Non-destructive (choice b): the BMLD write replaces ONLY this run's own cases
    on each touched element — other cases (Dead/Live/EQ and other wind directions)
    from a previous push are read back and preserved (see merge_bmld). Returns the
    number of NEW BMLD items pushed.
    """
    import midas_gen as mg

    force_unit, dist_unit = read_model_units(mg)
    names = list(cases)

    sp = stld_payload(names, mg.MidasAPI("GET", "/db/STLD").get("STLD", {}),
                      types=case_types)
    if sp["Assign"]:
        mg.MidasAPI("PUT", "/db/STLD", sp)

    if use_load_groups:
        lp = ldgr_payload(names, mg.MidasAPI("GET", "/db/LDGR").get("LDGR", {}))
        if lp["Assign"]:
            mg.MidasAPI("PUT", "/db/LDGR", lp)

    new_bp = bmld_payload(cases, role_map, units, force_unit, dist_unit,
                          use_load_groups, ridge_azimuth_deg=ridge_azimuth_deg)
    existing = mg.MidasAPI("GET", "/db/BMLD").get("BMLD", {})
    bp = merge_bmld(existing, new_bp, own_case_names=names)
    if bp["Assign"]:
        put_bmld_chunked(mg, bp["Assign"])      # chunked: a single huge PUT fails
    return bmld_item_count(new_bp)
