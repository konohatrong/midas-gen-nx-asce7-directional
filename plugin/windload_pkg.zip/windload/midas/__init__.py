"""MIDAS GEN NX adapter (Phase 3) — the ONLY part that imports midas_gen.

Keeps the compute core (windload.asce7/geometry/loads) MIDAS-free. This module
turns the core's MemberLoad output into a live model: build geometry, compute
loads with the tested core, push as /db/BMLD.

NOTE: importing this requires `midas-gen` installed and a running GEN NX for the
live calls. The pure core does NOT import this.
"""
from .connection import connect, REGIONAL
from .build import clear_model, build_geometry
from .push import push_loads
from .runner import generate_and_assign

__all__ = ["connect", "REGIONAL", "clear_model", "build_geometry",
           "push_loads", "generate_and_assign"]
