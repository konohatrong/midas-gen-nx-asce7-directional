"""Pure builders for MIDAS /db payloads — no midas_gen, no HTTP.

These turn compute-core output into the exact JSON that gets PUT to /db/STLD,
/db/LDGR and /db/BMLD. push.py (desktop, via midas_gen) and the Pyodide plug-in
(browser, via fetch) both call these, so the load-mapping logic has one home.
"""
from __future__ import annotations

from ..units import UnitSystem, line_load_to_model
from .members import Member
from .transform import world_components


def bmld_payload(cases: dict, role_map: dict, units: UnitSystem,
                 force_unit: str = "KN", dist_unit: str = "M",
                 use_load_groups: bool = True,
                 ridge_azimuth_deg: float = 90.0) -> dict:
    """Build the /db/BMLD Assign payload from compute_loads() output.

    role_map value may be an int element id (generate path) or a Member chain
    (pull path -> loads distributed across meshed pieces). D clamped to [0,1].
    ridge_azimuth_deg: building orientation (ridge from +X, CCW+). Segment
    directions are BUILDING-LOCAL; at azimuth != 90 each horizontal load is
    decomposed into its world GX + GY components (see transform).
    """
    assign: dict = {}

    def add(eid, case, group, direction, d0, d1, w0, w1, projection=False):
        d0 = min(1.0, max(0.0, d0))
        d1 = min(1.0, max(0.0, d1))
        if d1 - d0 <= 1e-9:                       # drop degenerate segments
            return
        items = assign.setdefault(str(eid), {"ITEMS": []})["ITEMS"]
        for wdir, p0, p1 in world_components(direction, w0, w1,
                                             ridge_azimuth_deg):
            items.append({
                "ID": len(items) + 1, "LCNAME": case, "GROUP_NAME": group,
                "CMD": "BEAM", "TYPE": "UNILOAD", "DIRECTION": wdir,
                "USE_PROJECTION": projection, "USE_ECCEN": False,
                "D": [d0, d1, 0, 0], "P": [p0, p1, 0, 0]})

    def conv(w):
        return line_load_to_model(w, units, force_unit, dist_unit)

    for case, members in cases.items():
        group_name = case if use_load_groups else ""
        for m in members:
            target = role_map.get((m.frame, m.role))
            if target is None:
                continue
            if isinstance(target, Member):
                for s in m.segments:
                    for eid, (d0, d1), (cw0, cw1) in target.distribute(
                            [(s.d0, s.d1, s.w0, s.w1)]):
                        add(eid, case, group_name, s.direction,
                            d0, d1, conv(cw0), conv(cw1), s.use_projection)
            else:
                for s in m.segments:
                    add(target, case, group_name, s.direction,
                        s.d0, s.d1, conv(s.w0), conv(s.w1), s.use_projection)
    return {"Assign": assign}


def _merge_named(names, existing: dict, extra=None, type_for=None) -> dict:
    """Assign payload that adds each name not already present, with fresh IDs.

    type_for(name) -> load TYPE string (overrides extra['TYPE']) for static cases
    that aren't wind (Dead='D', Roof Live='L', ...)."""
    present = {v.get("NAME") for v in existing.values()}
    next_id = max((int(k) for k in existing), default=0) + 1
    assign: dict = {}
    for nm in names:
        if nm in present:
            continue
        row = {"NAME": nm}
        if extra:
            row.update(extra)
        if type_for is not None:
            row["TYPE"] = type_for(nm)
        assign[str(next_id)] = row
        present.add(nm)
        next_id += 1
    return {"Assign": assign}


def stld_payload(case_names, existing: dict, types: dict | None = None) -> dict:
    """Static load cases merged into existing /db/STLD. Default TYPE 'W' (wind);
    pass `types` {name: 'D'|'L'|...} for gravity/other cases."""
    type_for = (lambda nm: (types or {}).get(nm, "W")) if types else None
    return _merge_named(case_names, existing, extra={"TYPE": "W", "DESC": ""},
                        type_for=type_for)


def ldgr_payload(case_names, existing: dict) -> dict:
    """Load groups (one per case), merged into existing /db/LDGR."""
    return _merge_named(case_names, existing)


def bmld_item_count(payload: dict) -> int:
    return sum(len(v["ITEMS"]) for v in payload.get("Assign", {}).values())


def merge_bmld(existing_bmld: dict, new_payload: dict, own_case_names) -> dict:
    """Scoped, non-destructive merge of new wind loads into existing /db/BMLD.

    Choice (b): a push replaces ONLY its own wind cases. On every affected
    element we keep every item whose LCNAME is NOT in own_case_names (Dead, Live,
    Earthquake, *other* wind directions from a previous run...) and append this
    run's new wind items. Other load cases — and wind cases this run didn't
    compute — are preserved untouched.

    `existing_bmld` is the GET /db/BMLD 'BMLD' dict ({elem_id: {ITEMS:[...]}}).
    Returns an Assign payload that, when PUT, leaves non-wind loads intact.

    Affected elements = those getting new items, PLUS any element still carrying
    one of THIS run's cases from a prior push (so a re-run cleanly replaces them
    even where geometry no longer produces a load — that element's ITEMS go to
    just its kept non-wind loads, possibly empty).
    """
    own = set(own_case_names)
    new_assign = new_payload.get("Assign", {})
    existing = existing_bmld or {}

    affected = set(new_assign)
    for eid, entry in existing.items():
        if any(it.get("LCNAME") in own for it in entry.get("ITEMS", [])):
            affected.add(str(eid))

    merged: dict = {}
    for eid in affected:
        kept = [it for it in existing.get(eid, {}).get("ITEMS", [])
                if it.get("LCNAME") not in own]          # Dead/Live/EQ/other wind
        items = kept + list(new_assign.get(eid, {}).get("ITEMS", []))
        out_items = []
        for i, it in enumerate(items, start=1):           # renumber within element
            it = dict(it)
            it["ID"] = i
            out_items.append(it)
        merged[eid] = {"ITEMS": out_items}
    return {"Assign": merged}
