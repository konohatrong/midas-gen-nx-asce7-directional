"""End-to-end: connect, build geometry, compute (tested core), push loads."""
from __future__ import annotations

from ..geometry import Building
from ..loads import WindParams, compute_loads, filter_surfaces
from .build import build_geometry, clear_model
from .classify import reconstruct
from .connection import connect
from .pull import read_model
from .push import push_loads
from .transform import to_local


def _pull(wind_dir: str = "+X", ridge_azimuth_deg: float = 90.0):
    """read_model -> world->local transform (user-defined ridge azimuth, auto
    origin) -> reconstruct. Adds the applied transform to report.notes."""
    raw, tf = to_local(read_model(), ridge_azimuth_deg)
    pulled = reconstruct(raw, wind=wind_dir)
    ox, oy, oz = tf["origin_world"]
    pulled.report.notes.append(
        f"orientation: ridge azimuth {ridge_azimuth_deg:g} deg (from +X, CCW+); "
        f"auto origin at world ({ox:.3f}, {oy:.3f}, {oz:.3f})"
        + (f"; base Z={tf['base_z']:g} subtracted" if abs(tf["base_z"]) > 1e-9
           else ""))
    return pulled


def _all_cases(building, wind, directions):
    cases = {}
    for d in directions:
        cases.update(compute_loads(building, wind, direction=d))
    return cases


def generate_and_assign_mwfrs(building: Building, wind: WindParams, key: str,
                              axes=("+X", "-X", "+Y", "-Y"),
                              clear: bool = True) -> dict:
    """Generate the model and assign the FULL ASCE 7-22 Fig 27.3-8 MWFRS set
    (C1-C4 over all wind senses; full / torsion / diagonal / diagonal+torsion).
    Torsion via linear-graded frame loads (#2)."""
    from ..mwfrs import mwfrs_cases
    url = connect(key)
    if clear:
        clear_model()
    role_map = build_geometry(building)
    cases = mwfrs_cases(building, wind, axes=axes)
    n_loads = push_loads(cases, role_map, wind.units)
    return {"base_url": url, "frames": building.n_frames,
            "roof_type": building.roof_type, "cases": list(cases),
            "n_cases": len(cases), "bmld_items": n_loads}


def generate_and_assign(building: Building, wind: WindParams, key: str,
                        directions=("+X",), clear: bool = True,
                        surfaces=None) -> dict:
    """Generate the gable model and assign ASCE 7-22 wind (+/-GCpi) in GEN NX.

    directions: any of '+X','-X','+Y','-Y'. Uses the pure compute core for all
    engineering; this only handles MIDAS I/O.
    surfaces: optional subset of loads.SURFACES to push only those surfaces (#4)
    — e.g. ('WWroof',) pushes only the windward roof for the chosen directions.
    """
    url = connect(key)
    if clear:
        clear_model()
    role_map = build_geometry(building)
    cases = filter_surfaces(_all_cases(building, wind, directions), surfaces)
    n_loads = push_loads(cases, role_map, wind.units)
    elems_per_frame = 3 if building.is_monoslope else 4
    return {
        "base_url": url,
        "frames": building.n_frames,
        "roof_type": building.roof_type,
        "elements": elems_per_frame * building.n_frames + len(building.end_posts()),
        "end_posts": len(building.end_posts()),
        "cases": list(cases),
        "bmld_items": n_loads,
        "tributaries": building.tributaries(),
    }


# The tool's canonical tagging-group names (what build_geometry /
# create_tagging_groups produce). Matched EXACTLY (+ "endwall" prefix for
# ENDWALL0/1) so unrelated groups like "Roof Bottom Chord" don't false-match.
_TAG_EXACT = {"wwcol", "lwcol", "wwroof", "lwroof", "roof", "corner"}


def _is_wind_tag(name: str) -> bool:
    n = name.strip().lower()
    return n in _TAG_EXACT or n.startswith("endwall") or n.startswith("epost")


def _tag_summary() -> dict:
    """Which of the tool's tagging groups exist + how many elements they cover.
    Call while already connected."""
    import midas_gen as mg
    grup = mg.MidasAPI("GET", "/db/GRUP").get("GRUP", {})
    n_elems = len(mg.MidasAPI("GET", "/db/ELEM").get("ELEM", {}))
    groups: dict = {}
    tagged: set = set()
    for g in grup.values():
        name = g.get("NAME", "")
        if name and _is_wind_tag(name):
            elist = [int(e) for e in (g.get("E_LIST", []) or [])]
            groups[name] = len(elist)
            tagged.update(elist)
    return {"total_elements": n_elems, "groups": groups,
            "group_count": len(groups), "tagged_elements": len(tagged),
            "has_tags": bool(groups)}


def tag_status(key: str) -> dict:
    """Re-read the open model and report its wind-tag status (the GUI Refresh:
    use after creating/assigning Structure Groups in GEN NX to re-align)."""
    connect(key)
    return _tag_summary()


def test_connection(key: str) -> dict:
    """Connect and report the product/server + tag status (Step 1 of the GUI)."""
    url = connect(key)
    import midas_gen as mg
    n_nodes = len(mg.MidasAPI("GET", "/db/NODE").get("NODE", {}))
    n_elems = len(mg.MidasAPI("GET", "/db/ELEM").get("ELEM", {}))
    return {"connected": True, "base_url": url,
            "nodes": n_nodes, "elements": n_elems,
            "has_model": n_elems > 0, "tags": _tag_summary()}


def create_groups(key: str, names=None) -> dict:
    """Create the tool's tagging Structure Groups (non-destructive: keeps any
    existing project groups)."""
    from .build import create_tagging_groups
    connect(key)
    return create_tagging_groups(names)      # {created, skipped, existing_kept}


def generate_and_assign_full(building: Building, wind: WindParams, key: str,
                             dead: float = 0.0, live: float = 0.0,
                             directions=("+X", "-X", "+Y", "-Y"),
                             include_mwfrs: bool = True,
                             mwfrs_axes=("+X", "-X", "+Y", "-Y"),
                             clear: bool = True) -> dict:
    """Generate the model and assign the FULL load set in canonical professional
    order (#sequence): Dead, Roof Live, wind (+/-X +/-Y, each +/-GCpi), then MWFRS
    C1-C4. Pushed in ONE ordered pass so /db/STLD numbering follows the sequence.

    With clear=True the stale /db/STLD + /db/LDGR are also wiped first so the case
    list is fresh and correctly ordered (the generate path builds a new model).
    """
    from ..gravity import roof_gravity_cases, GRAVITY_CASE_TYPES
    from ..mwfrs import mwfrs_cases
    from ..ordering import order_cases

    url = connect(key)
    if clear:
        clear_model()
        import midas_gen as mg
        mg.MidasAPI("DELETE", "/db/STLD")        # fresh, sequentially-numbered cases
        mg.MidasAPI("DELETE", "/db/LDGR")
    role_map = build_geometry(building)

    cases: dict = {}
    cases.update(roof_gravity_cases(building, dead, live))      # Dead, Roof Live
    for d in directions:
        cases.update(compute_loads(building, wind, direction=d))
    if include_mwfrs:
        cases.update(mwfrs_cases(building, wind, axes=mwfrs_axes))
    cases = order_cases(cases)                                  # canonical sequence

    n_loads = push_loads(cases, role_map, wind.units,
                         case_types=GRAVITY_CASE_TYPES)
    return {"base_url": url, "n_cases": len(cases), "cases": list(cases),
            "bmld_items": n_loads}


def generate_and_assign_gravity(building: Building, key: str, dead: float,
                                live: float, units, clear: bool = True) -> dict:
    """Generate the model and assign roof gravity (Dead + Roof Live) line loads
    (#3). dead/live are roof pressures in the core base unit (SI N/m^2, US lb/ft^2).
    """
    from ..gravity import roof_gravity_cases, GRAVITY_CASE_TYPES
    url = connect(key)
    if clear:
        clear_model()
    role_map = build_geometry(building)
    cases = roof_gravity_cases(building, dead, live)
    n_loads = push_loads(cases, role_map, units, case_types=GRAVITY_CASE_TYPES)
    return {"base_url": url, "cases": list(cases), "bmld_items": n_loads}


def assign_full_to_existing(wind: WindParams, key: str,
                            dead: float = 0.0, live: float = 0.0,
                            directions=("+X", "-X", "+Y", "-Y"),
                            include_mwfrs: bool = True,
                            mwfrs_axes=("+X", "-X", "+Y", "-Y"),
                            surfaces=None,
                            ridge_azimuth_deg: float = 90.0) -> dict:
    """Pull an EXISTING model and assign the FULL ordered load set: Dead, Roof
    Live, wind (each direction x +/-GCpi), MWFRS C1-C4 — the same set as
    generate_and_assign_full, but on the user's own (tagged) model.

    ridge_azimuth_deg: building orientation (ridge from +X, CCW+; user-defined,
    origin auto-detected). All engineering runs in building-local axes; the push
    decomposes horizontal loads into world GX+GY at azimuth != 90.
    Non-destructive (choice b): replaces only this run's own cases per element.
    """
    from ..gravity import roof_gravity_cases, GRAVITY_CASE_TYPES
    from ..mwfrs import mwfrs_cases
    from ..ordering import order_cases

    url = connect(key)
    pulled = _pull(directions[0], ridge_azimuth_deg)

    cases: dict = {}
    cases.update(roof_gravity_cases(pulled.building, dead, live))
    for d in directions:
        cases.update(compute_loads(pulled.building, wind, direction=d))
    if include_mwfrs:
        cases.update(mwfrs_cases(pulled.building, wind, axes=mwfrs_axes))
    cases = order_cases(filter_surfaces(cases, surfaces))

    n_loads = push_loads(cases, pulled.role_map, wind.units,
                         case_types=GRAVITY_CASE_TYPES,
                         ridge_azimuth_deg=ridge_azimuth_deg)
    return {"base_url": url, "report": pulled.report, "n_cases": len(cases),
            "cases": list(cases), "bmld_items": n_loads}


def assign_gravity_to_existing(building: Building, key: str, dead: float,
                               live: float, units, wind_dir: str = "+X",
                               ridge_azimuth_deg: float = 90.0) -> dict:
    """Pull an existing model, reconstruct roles, and assign roof gravity (#3).
    Non-destructive: replaces only the Dead / Roof Live cases (see push_loads)."""
    from ..gravity import roof_gravity_cases, GRAVITY_CASE_TYPES
    url = connect(key)
    pulled = _pull(wind_dir, ridge_azimuth_deg)
    cases = roof_gravity_cases(pulled.building, dead, live)
    n_loads = push_loads(cases, pulled.role_map, units,
                         case_types=GRAVITY_CASE_TYPES,
                         ridge_azimuth_deg=ridge_azimuth_deg)
    return {"base_url": url, "report": pulled.report, "cases": list(cases),
            "bmld_items": n_loads}


def pull_and_review(key: str, wind_dir: str = "+X",
                    ridge_azimuth_deg: float = 90.0) -> "object":
    """Read-only: pull an existing model, reconstruct, return PulledModel.

    Use to review the extracted building + roles (the verify gate, #9) BEFORE
    assigning loads. ridge_azimuth_deg: ridge direction from global +X, CCW+
    (user-defined; presets 0=along X, 90=along Y; origin is auto-detected).
    """
    connect(key)
    return _pull(wind_dir, ridge_azimuth_deg)


def assign_to_existing(wind: WindParams, key: str, directions=("+X",),
                       surfaces=None, ridge_azimuth_deg: float = 90.0) -> dict:
    """Pull an EXISTING model, reconstruct, compute, and assign wind loads.

    Does not create geometry and does NOT wipe the model's beam loads. The push
    replaces ONLY this run's own wind cases per element (choice b); Dead/Live/EQ
    and other wind directions are read back and preserved (see push.push_loads ->
    payload.merge_bmld). Re-running the same directions is idempotent.
    surfaces: optional subset of loads.SURFACES to push only those surfaces (#4).
    ridge_azimuth_deg: building orientation (ridge from +X, CCW+; user-defined,
    origin auto-detected). Wind '+X'/'-X' stay BUILDING-relative (across the
    ridge); pushed loads are decomposed into world GX+GY at azimuth != 90.
    """
    url = connect(key)
    pulled = _pull(directions[0], ridge_azimuth_deg)
    cases = filter_surfaces(_all_cases(pulled.building, wind, directions), surfaces)
    n_loads = push_loads(cases, pulled.role_map, wind.units,
                         ridge_azimuth_deg=ridge_azimuth_deg)
    return {
        "base_url": url,
        "report": pulled.report,
        "cases": list(cases),
        "bmld_items": n_loads,
    }
