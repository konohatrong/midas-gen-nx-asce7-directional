"""Unit systems for the wind load generator.

ASCE 7-22 velocity pressure uses a unit-dependent constant:
    US:  qz = 0.00256 Kz Kzt Ke V^2   (lb/ft^2,  V in mph, z in ft)
    SI:  qz = 0.613  Kz Kzt Ke V^2    (N/m^2,   V in m/s, z in m)

The compute core works in the chosen system's *base* pressure unit (lb/ft^2 or
N/m^2). Convert to the MIDAS model's units at the edge (e.g. N/m^2 -> kN/m^2 by
/1000).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class UnitSystem:
    name: str
    qz_const: float    # velocity-pressure constant (Eq 26.10-1)
    speed: str         # basic wind speed unit
    length: str        # length unit
    pressure: str      # resulting pressure unit


US = UnitSystem("US", 0.00256, "mph", "ft", "lb/ft^2")
SI = UnitSystem("SI", 0.613, "m/s", "m", "N/m^2")

_BY_NAME = {"US": US, "SI": SI}


def get_units(name: str) -> UnitSystem:
    key = name.upper()
    if key not in _BY_NAME:
        raise ValueError(f"unknown unit system {name!r}; use 'US' or 'SI'")
    return _BY_NAME[key]


def to_kN_per_m2(pressure: float, units: UnitSystem) -> float:
    """Convert a core pressure result to kN/m^2 (MIDAS GEN NX force unit kN)."""
    if units is SI:            # N/m^2 -> kN/m^2
        return pressure / 1000.0
    if units is US:            # lb/ft^2 -> kN/m^2
        return pressure * 0.0478802589
    raise ValueError("unknown unit system")


# --- MIDAS model unit factors (read from /db/UNIT) ---------------------------
# Force unit -> newtons; length unit -> metres. Used to convert a core line load
# into whatever FORCE/DIST the open MIDAS model actually uses.
_FORCE_TO_N = {
    "N": 1.0, "KN": 1000.0, "KGF": 9.80665, "TONF": 9806.65,
    "LBF": 4.4482216, "KIPS": 4448.2216, "KIP": 4448.2216,
}
_DIST_TO_M = {"M": 1.0, "CM": 0.01, "MM": 0.001, "FT": 0.3048, "IN": 0.0254}


def _line_load_to_N_per_m(w: float, units: UnitSystem) -> float:
    """Core line load (SI=N/m, US=lb/ft) -> N/m (canonical)."""
    if units is SI:            # already N/m
        return w
    if units is US:            # lb/ft -> N/m
        return w * 14.5939
    raise ValueError("unknown unit system")


def line_load_to_model(w: float, units: UnitSystem,
                       force_unit: str = "KN", dist_unit: str = "M") -> float:
    """Convert a core line load to the open model's FORCE/DIST units.

    force_unit / dist_unit come from GET /db/UNIT (e.g. 'KN','M' or 'TONF','CM').
    """
    npm = _line_load_to_N_per_m(w, units)
    f = _FORCE_TO_N.get(force_unit.upper())
    d = _DIST_TO_M.get(dist_unit.upper())
    if f is None or d is None:
        raise ValueError(f"unsupported model units: {force_unit}/{dist_unit}")
    return npm * d / f          # (N/m) * (m per dist) / (N per force) = force/dist


def line_load_to_kN_per_m(w: float, units: UnitSystem) -> float:
    """Convert a core line load (pressure*length) to kN/m for a kN,m MIDAS model.

    SI core line load is N/m; US is lb/ft. Thin wrapper over line_load_to_model.
    """
    return line_load_to_model(w, units, "KN", "M")
