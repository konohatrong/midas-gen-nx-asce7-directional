"""Preview/summary of a wind load run (pure; no MIDAS). Used by the GUI.

Derives the per-surface net pressures from the SAME compute_loads output that
gets pushed, so the preview always matches what the engine assigns.
"""
from __future__ import annotations

from . import asce7
from .geometry import Building
from .loads import WindParams, compute_loads

_MAIN_ROLES = ("WWcol", "LWcol", "WWroof", "LWroof")


def pressure_table(building: Building, wind: WindParams, direction: str) -> list:
    """Net pressures (load / tributary) on the main surfaces of an interior frame.

    Returns rows: {role, dir, zone, '+GCpi', '-GCpi'} in the unit system's
    pressure unit.
    """
    cases = compute_loads(building, wind, direction=direction)
    fi = 1 if building.n_frames > 2 else 0          # interior frame (no corners)
    t = building.tributary(fi)
    rows: dict = {}
    for cname, members in cases.items():
        for m in members:
            if m.frame != fi or m.role not in _MAIN_ROLES:
                continue
            for si, s in enumerate(m.segments):
                key = (m.role, s.direction, si)
                rows.setdefault(key, {"role": m.role, "dir": s.direction,
                                      "zone": si})
                rows[key][cname] = round(s.pressure, 2)   # signed ASCE net pressure
    return list(rows.values())


def preview(building: Building, wind: WindParams, directions) -> dict:
    """JSON-friendly summary: geometry, qh, and per-direction pressure tables."""
    b, w = building, wind
    h = b.mean_roof_height
    qh = asce7.qz(h, w.V, w.exposure, w.units, w.Kzt, w.Ke)
    out = {
        "geometry": {
            "frames": b.n_frames, "span": b.span, "eave": b.eave_height,
            "ridge": round(b.ridge_height, 2), "h": round(h, 2),
            "h_over_L": round(b.h_over_L("normal"), 3),
            "roof_angle_deg": round(b.roof_angle_deg, 2),
            "tributaries": [round(x, 2) for x in b.tributaries()],
            "end_posts": len(b.end_posts()),
        },
        "wind": {
            "V": w.V, "exposure": w.exposure, "units": w.units.name,
            "pressure_unit": w.units.pressure, "qh": round(qh, 2),
            "enclosure": w.enclosure, "GCpi": w.gcpi,
        },
        "directions": {},
    }
    total = 0
    for d in directions:
        cases = compute_loads(b, w, direction=d)
        total += sum(len(v) for v in cases.values())
        out["directions"][d] = {"cases": list(cases),
                                "pressures": pressure_table(b, w, d)}
    out["total_cases"] = sum(len(out["directions"][d]["cases"])
                             for d in directions)
    out["total_member_loads"] = total
    return out
