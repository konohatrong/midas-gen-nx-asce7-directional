"""Surface pressures -> per-member line loads (the heart of the compute core).

Turns a Building + WindParams into MemberLoad objects: for each frame and each
surface (windward/leeward wall & roof), the line load(s) with direction and
relative D-ranges (for stepped/zoned loads). Pure; no MIDAS. The MIDAS adapter
(Phase 3) translates MemberLoad -> /db/BMLD.

Convention (wind NORMAL to ridge, blowing +X; windward at X=0):
  - wall load (global +X) = p * inward_normal_X * tributary
        inward_normal_X = +1 (windward) , -1 (leeward)
  - roof load (local +LZ = uplift, away from roof top) = -p * tributary
These reproduce the validated prototypes.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace

from . import asce7
from .geometry import Building
from .units import UnitSystem, SI


@dataclass
class WindParams:
    V: float                                   # basic wind speed (units.speed)
    exposure: str = "C"
    units: UnitSystem = SI
    Kzt: float = 1.0
    Ke: float = 1.0
    enclosure: str = "enclosed"                # -> GCpi
    Kd: float = asce7.KD_BUILDING
    G: float = asce7.G_RIGID
    wall_zone_heights: list[float] | None = None   # explicit windward-wall height
    #   zone breakpoints [0, z1, z2, ..., top]; q_z is evaluated per zone so the
    #   windward-wall pressure steps UP with height (taller q_z higher up).
    wall_zone_height: float | None = None      # convenience: auto-zone every this
    #   many height units (ignored if wall_zone_heights is given). None -> 1 zone.
    wall_qz_at: str = "mid"                    # 'mid' or 'top' of each zone

    @property
    def gcpi(self) -> float:
        return asce7.GCPI[self.enclosure]

    def wall_zones(self, top: float) -> list[float]:
        """Windward-wall height zone breakpoints up to `top`. Explicit list wins;
        else step by wall_zone_height; else a single zone [0, top]."""
        if self.wall_zone_heights:
            return self.wall_zone_heights
        step = self.wall_zone_height
        if step and step > 0:
            zs = [0.0]
            while zs[-1] + step < top - 1e-9:
                zs.append(zs[-1] + step)
            zs.append(top)
            return zs
        return [0.0, top]


@dataclass
class LoadSegment:
    d0: float            # relative start along element (0..1, i-end=0)
    d1: float            # relative end
    w0: float            # line load at d0 (force/length, units.pressure * length)
    w1: float            # line load at d1
    direction: str       # 'GX'|'GY'|'GZ'|'LX'|'LY'|'LZ'
    pressure: float = 0.0  # signed ASCE net pressure p (toward surface +)
    use_projection: bool = False  # apply over the member's projected length (e.g.
    #   roof live load on the horizontal projection); False = actual length


@dataclass
class MemberLoad:
    frame: int
    role: str            # 'WWcol'|'LWcol'|'WWroof'|'LWroof'
    case: str
    segments: list[LoadSegment] = field(default_factory=list)


def _qz(z, w, b):
    return asce7.qz(z, w.V, w.exposure, w.units, w.Kzt, w.Ke)


# inward-normal X-component for each long-wall column (interior between X=0..span)
INWARD_NX = {"WWcol": +1.0, "LWcol": -1.0}

DIRECTIONS = ("+X", "-X", "+Y", "-Y")


def _add_longitudinal(members, b, w, i, direction, case, gs, qh_i, tops, dp):
    """Longitudinal (GY) load on frame i from the TAPERED long walls under wind
    parallel to ridge. Each wall's plan-projected X width (proj_tributary) catches
    the wind: the wall facing INTO it gets windward Cp (q_z stepped up the column's
    height); the wall facing away gets leeward Cp. Force acts in the wind direction;
    a non-tapered wall (zero projection) contributes nothing. `tops` = column height
    per role (gable both = eave; monoslope low/high eave)."""
    sgn_y = 1.0 if direction == "+Y" else -1.0
    for role, lee in (("WWcol", False), ("LWcol", True)):
        tp = b.proj_tributary(i, lee)
        if abs(tp) < 1e-9:
            continue
        top = tops[role]
        into = (tp > 0) == (direction == "+Y")
        if into:                              # windward face: q_z stepped by height
            segs = []
            for z0, z1 in zip(w.wall_zones(top)[:-1], w.wall_zones(top)[1:]):
                zref = (z0 + z1) / 2 if w.wall_qz_at == "mid" else z1
                p = dp(_qz(zref, w, b), asce7.cp_windward_wall(), gs, qh_i)
                wl = p * abs(tp) * sgn_y
                segs.append(LoadSegment(z0 / top, z1 / top, wl, wl, "GY", p))
            members.append(MemberLoad(i, role, case, segs))
        else:                                 # leeward face: uniform suction
            p = dp(qh_i, asce7.cp_leeward_wall(b.L_over_B("parallel")), gs, qh_i)
            wl = -p * abs(tp) * sgn_y
            members.append(MemberLoad(i, role, case,
                                      [LoadSegment(0, 1, wl, wl, "GY", p)]))


def _normal_roof_segments(x_i, x_j, direction, span, h, hL):
    """(d0, d1, cp) along a rafter for a LOW-SLOPE roof, normal-to-ridge wind.

    Zones run by horizontal distance from the windward edge (x=0 for +X, x=span
    for -X). x_i, x_j are the geometric X at the element's i/j ends.
    """
    def dist(x):
        return x if direction == "+X" else span - x

    def x_of(d):
        return d if direction == "+X" else span - d

    bounds = [h, 2 * h] if hL <= 0.5 else [0.5 * h]
    di, dj = dist(x_i), dist(x_j)
    lo, hi = min(di, dj), max(di, dj)
    cuts = sorted({lo, hi} | {b for b in bounds if lo < b < hi})
    segs = []
    for a, b in zip(cuts[:-1], cuts[1:]):
        cp = asce7.cp_roof_zoned((a + b) / 2, h, hL)[0]
        da = (x_of(a) - x_i) / (x_j - x_i)
        db = (x_of(b) - x_i) / (x_j - x_i)
        segs.append((min(da, db), max(da, db), cp))
    return segs


def compute_loads(building: Building, wind: WindParams,
                  direction: str = "+X", gcpi_signs=(+1, -1),
                  roof_case: str = "uplift") -> dict[str, list[MemberLoad]]:
    """Member loads for one wind direction, per +/-GCpi case.

    direction: '+X'|'-X' (normal to ridge) or '+Y'|'-Y' (parallel to ridge).
    roof_case: 'uplift' (more-negative Cp) or 'downward' (the alternate Cp) for
               theta>=10 normal-to-ridge roofs.
    Returns {case_name: [MemberLoad, ...]}.
    """
    if direction not in DIRECTIONS:
        raise ValueError(f"direction must be one of {DIRECTIONS}")
    if building.is_monoslope:
        return _monoslope_loads(building, wind, direction, gcpi_signs, roof_case)
    b, w = building, wind
    normal = direction in ("+X", "-X")
    theta = b.roof_angle_deg

    def dp(q, cp, gs, qhi):                       # qi = that frame's q_h (taper)
        return asce7.design_pressure(q, cp, qhi, gs, w.Kd, w.G)

    # which physical member is aerodynamically windward/leeward
    if direction == "+X":
        ww_col, lw_col, ww_roof, lw_roof = "WWcol", "LWcol", "WWroof", "LWroof"
    elif direction == "-X":
        ww_col, lw_col, ww_roof, lw_roof = "LWcol", "WWcol", "LWroof", "WWroof"

    out: dict[str, list[MemberLoad]] = {}
    for sign in gcpi_signs:
        gs = sign * w.gcpi
        case = f"Wind {direction} {'+' if sign > 0 else '-'}GCpi"
        members: list[MemberLoad] = []
        for i in range(b.n_frames):
            # per-side tributary: windward vs leeward wall can differ in length on a
            # splayed/tapered plan -> different tributary per physical role.
            t_ww, t_lw = b.tributary_windward(i), b.tributary_leeward(i)
            trib = {"WWcol": t_ww, "WWroof": t_ww, "LWcol": t_lw, "LWroof": t_lw}
            # per-frame geometry (tapered span / per-frame eave -> per-frame h, q_h)
            span_i = b.span_at(i)
            eave_i = b.eave_at(i)
            zones = w.wall_zones(eave_i)              # windward-wall height zones
            h_i = b.mean_roof_height_at(i)
            qh_i = _qz(h_i, w, b)

            if normal:
                hL_i = b.h_over_L_at(i, "normal")
                LoverB_i = b.leeward_LoverB_at(i, "normal")   # conservative (#1)
                xr = b.ridge_x_at(i)
                # windward wall (column): stepped height zones
                segs = []
                for z0, z1 in zip(zones[:-1], zones[1:]):
                    zref = (z0 + z1) / 2 if w.wall_qz_at == "mid" else z1
                    p = dp(_qz(zref, w, b), asce7.cp_windward_wall(), gs, qh_i)
                    wl = p * INWARD_NX[ww_col] * trib[ww_col]
                    segs.append(LoadSegment(z0 / eave_i, z1 / eave_i, wl, wl,
                                            "GX", p))
                members.append(MemberLoad(i, ww_col, case, segs))
                # leeward wall (column): uniform
                p = dp(qh_i, asce7.cp_leeward_wall(LoverB_i), gs, qh_i)
                wl = p * INWARD_NX[lw_col] * trib[lw_col]
                members.append(MemberLoad(i, lw_col, case,
                                          [LoadSegment(0, 1, wl, wl, "GX", p)]))
                # roof: per-plane angle (unequal-pitch gable, per-frame for a
                # ridge-aligned taper); ridge may be offset
                al_i, ar_i = b.angle_left_at(i), b.angle_right_at(i)
                theta_w = al_i if direction == "+X" else ar_i
                theta_l = ar_i if direction == "+X" else al_i
                if theta_w >= 10.0:                 # uniform per slope
                    pair = asce7.cp_windward_roof(hL_i, theta_w)
                    cp_w = pair[0] if roof_case == "uplift" else pair[1]
                    cp_l = asce7.cp_leeward_roof(hL_i, theta_l)
                    for role, cp in ((ww_roof, cp_w), (lw_roof, cp_l)):
                        p = dp(qh_i, cp, gs, qh_i)
                        wl = -p * trib[role]
                        members.append(MemberLoad(i, role, case,
                                                  [LoadSegment(0, 1, wl, wl, "LZ", p)]))
                else:                              # low slope -> zoned along x
                    for role, xi, xj in (("WWroof", 0.0, xr),
                                         ("LWroof", xr, span_i)):
                        segs = []
                        for d0, d1, cp in _normal_roof_segments(
                                xi, xj, direction, span_i, h_i, hL_i):
                            p = dp(qh_i, cp, gs, qh_i)
                            wl = -p * trib[role]
                            segs.append(LoadSegment(d0, d1, wl, wl, "LZ", p))
                        members.append(MemberLoad(i, role, case, segs))

            else:  # parallel to ridge (+Y / -Y)
                hL_i = b.h_over_L_at(i, "parallel")
                # both long-wall columns are SIDE walls (-0.7), uniform
                for role in ("WWcol", "LWcol"):
                    p = dp(qh_i, asce7.cp_side_wall(), gs, qh_i)
                    wl = p * INWARD_NX[role] * trib[role]
                    members.append(MemberLoad(i, role, case,
                                              [LoadSegment(0, 1, wl, wl, "GX", p)]))
                # roof zoned by distance from the windward GABLE END (along Y)
                y0, y1 = b.frame_positions[0], b.frame_positions[-1]
                yi = b.frame_positions[i]
                d = (yi - y0) if direction == "+Y" else (y1 - yi)
                cp = asce7.cp_roof_zoned(d, h_i, hL_i)[0]
                for role in ("WWroof", "LWroof"):
                    p = dp(qh_i, cp, gs, qh_i)
                    wl = -p * trib[role]
                    members.append(MemberLoad(i, role, case,
                                              [LoadSegment(0, 1, wl, wl, "LZ", p)]))
                # longitudinal load from TAPERED long walls: their plan-projected
                # (X) area catches the parallel wind and loads this frame too
                # (#tapered-longitudinal). Windward Cp (zoned by height) for the wall
                # facing INTO the wind; leeward Cp for the wall facing away.
                _add_longitudinal(members, b, w, i, direction, case, gs, qh_i,
                                  {"WWcol": eave_i, "LWcol": eave_i}, dp)

            # --- corner columns: end-frame columns ALSO carry the gable-end
            #     wall (in Y) -> they resist both wind directions. Tributary is
            #     per-side so irregular pulled posts split the wall correctly. ---
            end = b.end_index_of_frame(i)
            if end is not None:
                inward_ny = +1.0 if end == 0 else -1.0
                if not normal:                   # parallel: windward/leeward gable
                    windward_end = 0 if direction == "+Y" else 1
                    if end == windward_end:
                        q, cp = _qz(eave_i / 2, w, b), asce7.cp_windward_wall()
                    else:
                        q, cp = qh_i, asce7.cp_leeward_wall(b.L_over_B("parallel"))
                else:                            # normal: gable end is a side wall
                    q, cp = qh_i, asce7.cp_side_wall()
                p = dp(q, cp, gs, qh_i)
                for role, sd in (("WWcol", "WW"), ("LWcol", "LW")):
                    wl = p * inward_ny * b.corner_gable_tributary_at(end, sd)
                    members.append(MemberLoad(i, role, case,
                                              [LoadSegment(0, 1, wl, wl, "GY", p)]))

        # --- gable-end wind posts (loaded in Y) ---
        for ep in b.end_posts():
            inward_ny = +1.0 if ep.end_idx == 0 else -1.0   # Y=min in +Y; Y=max -Y
            efi = 0 if ep.end_idx == 0 else b.n_frames - 1  # that end's frame
            qh_e = _qz(b.mean_roof_height_at(efi), w, b)
            if not normal:                       # parallel: windward/leeward gable
                windward_end = 0 if direction == "+Y" else 1
                if ep.end_idx == windward_end:
                    q, cp = _qz(ep.height / 2, w, b), asce7.cp_windward_wall()
                else:
                    q, cp = qh_e, asce7.cp_leeward_wall(b.L_over_B("parallel"))
            else:                                # normal: gable ends are side walls
                q, cp = qh_e, asce7.cp_side_wall()
            p = dp(q, cp, gs, qh_e)
            wl = p * inward_ny * ep.tributary
            members.append(MemberLoad(f"END{ep.end_idx}", f"post{ep.post_idx}",
                                      case, [LoadSegment(0, 1, wl, wl, "GY", p)]))

        out[case] = members
    return out


def _monoslope_loads(building: Building, wind: WindParams, direction: str,
                     gcpi_signs, roof_case: str) -> dict[str, list[MemberLoad]]:
    """Member loads for a MONOSLOPE building (one sloped roof plane).

    Roles: 'WWcol' = column at X=0 (low eave), 'LWcol' = column at X=span (high
    eave), 'ROOF' = the single rafter. Aerodynamic windward/leeward is chosen by
    `direction` (see docs/ASCE7-22_VALUES.md §11d): +X (low eave windward) -> roof
    uses WINDWARD Cp; -X (high eave windward) -> roof uses LEEWARD Cp.
    """
    b, w = building, wind
    normal = direction in ("+X", "-X")
    theta = b.roof_angle_deg

    def dp(q, cp, gs, qhi):                       # qi = that frame's q_h (taper)
        return asce7.design_pressure(q, cp, qhi, gs, w.Kd, w.G)

    out: dict[str, list[MemberLoad]] = {}
    for sign in gcpi_signs:
        gs = sign * w.gcpi
        case = f"Wind {direction} {'+' if sign > 0 else '-'}GCpi"
        members: list[MemberLoad] = []
        for i in range(b.n_frames):
            t_ww, t_lw = b.tributary_windward(i), b.tributary_leeward(i)
            t_roof = (t_ww + t_lw) / 2.0          # single plane spans both sides
            trib = {"WWcol": t_ww, "LWcol": t_lw}
            # per-frame geometry (tapered span / per-frame eave -> per-frame h, q_h)
            span_i = b.span_at(i)
            eave = b.eave_at(i)
            h_i = b.mean_roof_height_at(i)
            qh_i = _qz(h_i, w, b)
            high_eave_i = b.ridge_height_at(i)    # eave + span_i*tan(theta)

            if normal:
                hL_i = b.h_over_L_at(i, "normal")
                LoverB_i = b.leeward_LoverB_at(i, "normal")
                # pick the aerodynamically windward column + its height
                if direction == "+X":           # low eave (X=0) windward
                    ww_col, lw_col = "WWcol", "LWcol"
                    ww_h, roof_windward = eave, True
                else:                            # -X: high eave (X=span) windward
                    ww_col, lw_col = "LWcol", "WWcol"
                    ww_h, roof_windward = high_eave_i, False

                # windward wall: q_z stepped up the windward column's full height
                zones = w.wall_zones(ww_h)
                segs = []
                for z0, z1 in zip(zones[:-1], zones[1:]):
                    zref = (z0 + z1) / 2 if w.wall_qz_at == "mid" else z1
                    p = dp(_qz(zref, w, b), asce7.cp_windward_wall(), gs, qh_i)
                    wl = p * INWARD_NX[ww_col] * trib[ww_col]
                    segs.append(LoadSegment(z0 / ww_h, z1 / ww_h, wl, wl, "GX", p))
                members.append(MemberLoad(i, ww_col, case, segs))
                # leeward wall: uniform q_h
                p = dp(qh_i, asce7.cp_leeward_wall(LoverB_i), gs, qh_i)
                wl = p * INWARD_NX[lw_col] * trib[lw_col]
                members.append(MemberLoad(i, lw_col, case,
                                          [LoadSegment(0, 1, wl, wl, "GX", p)]))
                # single roof plane
                if theta >= 10.0:
                    if roof_windward:
                        pair = asce7.cp_windward_roof(hL_i, theta)
                        cp = pair[0] if roof_case == "uplift" else pair[1]
                    else:
                        cp = asce7.cp_leeward_roof(hL_i, theta)
                    p = dp(qh_i, cp, gs, qh_i)
                    members.append(MemberLoad(i, "ROOF", case,
                                              [LoadSegment(0, 1, -p * t_roof,
                                                           -p * t_roof, "LZ", p)]))
                else:                            # low slope -> zoned along rafter
                    segs = []
                    for d0, d1, cp in _normal_roof_segments(
                            0.0, span_i, direction, span_i, h_i, hL_i):
                        p = dp(qh_i, cp, gs, qh_i)
                        segs.append(LoadSegment(d0, d1, -p * t_roof, -p * t_roof,
                                                "LZ", p))
                    members.append(MemberLoad(i, "ROOF", case, segs))

            else:                                # parallel to ridge (+Y / -Y)
                hL_i = b.h_over_L_at(i, "parallel")
                for role in ("WWcol", "LWcol"):
                    p = dp(qh_i, asce7.cp_side_wall(), gs, qh_i)
                    wl = p * INWARD_NX[role] * trib[role]
                    members.append(MemberLoad(i, role, case,
                                              [LoadSegment(0, 1, wl, wl, "GX", p)]))
                y0, y1 = b.frame_positions[0], b.frame_positions[-1]
                yi = b.frame_positions[i]
                d = (yi - y0) if direction == "+Y" else (y1 - yi)
                cp = asce7.cp_roof_zoned(d, h_i, hL_i)[0]
                p = dp(qh_i, cp, gs, qh_i)
                members.append(MemberLoad(i, "ROOF", case,
                                          [LoadSegment(0, 1, -p * t_roof,
                                                       -p * t_roof, "LZ", p)]))
                # longitudinal load from tapered long walls (per-column heights:
                # WWcol = low eave, LWcol = high eave)
                _add_longitudinal(members, b, w, i, direction, case, gs, qh_i,
                                  {"WWcol": eave, "LWcol": high_eave_i}, dp)

            # corner columns: end-frame columns also carry the gable-end wall (Y),
            # per-side tributary (honors irregular pulled posts + taper). q for the
            # parallel-windward gable is taken at each column's own mid-height
            # (low/high eave differ on a monoslope).
            end = b.end_index_of_frame(i)
            if end is not None:
                inward_ny = +1.0 if end == 0 else -1.0
                col_h = {"WWcol": eave, "LWcol": high_eave_i}
                for role, sd in (("WWcol", "WW"), ("LWcol", "LW")):
                    if not normal:               # parallel: windward/leeward gable
                        windward_end = 0 if direction == "+Y" else 1
                        if end == windward_end:
                            q, cp = (_qz(col_h[role] / 2, w, b),
                                     asce7.cp_windward_wall())
                        else:
                            q, cp = qh_i, asce7.cp_leeward_wall(
                                b.L_over_B("parallel"))
                    else:                        # normal: gable end is a side wall
                        q, cp = qh_i, asce7.cp_side_wall()
                    p = dp(q, cp, gs, qh_i)
                    wl = p * inward_ny * b.corner_gable_tributary_at(end, sd)
                    members.append(MemberLoad(i, role, case,
                                              [LoadSegment(0, 1, wl, wl, "GY", p)]))

        # gable-end wind posts (loaded in Y); heights follow the monoslope profile
        for ep in b.end_posts():
            inward_ny = +1.0 if ep.end_idx == 0 else -1.0
            efi = 0 if ep.end_idx == 0 else b.n_frames - 1
            qh_e = _qz(b.mean_roof_height_at(efi), w, b)
            if not normal:
                windward_end = 0 if direction == "+Y" else 1
                if ep.end_idx == windward_end:
                    q, cp = _qz(ep.height / 2, w, b), asce7.cp_windward_wall()
                else:
                    q, cp = qh_e, asce7.cp_leeward_wall(b.L_over_B("parallel"))
            else:
                q, cp = qh_e, asce7.cp_side_wall()
            p = dp(q, cp, gs, qh_e)
            wl = p * inward_ny * ep.tributary
            members.append(MemberLoad(f"END{ep.end_idx}", f"post{ep.post_idx}",
                                      case, [LoadSegment(0, 1, wl, wl, "GY", p)]))

        out[case] = members
    return out


# --------------------------------------------------------------------------- #
# #4 — individual-surface selection (per surface x direction)
# --------------------------------------------------------------------------- #
# Selectable surface keys. Roof planes + long walls go by role; 'corner' is the
# gable-end (GY) load that end-frame columns also carry; 'post' is an end post.
SURFACES = ("WWcol", "LWcol", "WWroof", "LWroof", "ROOF", "corner", "post")


def surface_of(member: MemberLoad, segment: LoadSegment) -> str:
    """Surface key for one (member, segment) — what the user selects to push (#4)."""
    role = member.role
    if role in ("WWroof", "LWroof", "ROOF"):
        return role
    if role.startswith("post"):
        return "post"
    if role in ("WWcol", "LWcol"):
        # the gable-end load the corner columns also carry is in GY; the windward/
        # leeward (normal) or side (parallel) wall load is the column's GX/other.
        return "corner" if segment.direction == "GY" else role
    return role


def filter_surfaces(cases: dict, surfaces) -> dict:
    """Keep only the segments whose surface is in `surfaces`; drop emptied members
    and cases. `surfaces` is any subset of SURFACES. Pass None/empty -> unchanged."""
    if not surfaces:
        return cases
    keep = set(surfaces)
    out: dict = {}
    for case, members in cases.items():
        kept = []
        for m in members:
            segs = [s for s in m.segments if surface_of(m, s) in keep]
            if segs:
                kept.append(replace(m, segments=segs))
        if kept:
            out[case] = kept
    return out


def net_lateral(members: list[MemberLoad]) -> float:
    """Sum of horizontal (GX) line-load * tributary contributions, for checks."""
    total = 0.0
    for m in members:
        for s in m.segments:
            if s.direction == "GX":
                total += (s.w0 + s.w1) / 2 * abs(s.d1 - s.d0)
    return total
