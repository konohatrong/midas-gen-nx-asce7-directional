"""Canonical professional ordering of generated load cases.

Controls the /db/STLD case sequence (= MIDAS load-case numbering). Order:

  1. Dead
  2. Roof Live
  3. Wind, direction +X, -X, +Y, -Y — each +GCpi then -GCpi
  4. MWFRS C1..C4, each following the same direction sequence (then e+/e-, then
     +/-GCpi)

Pure name-based sort, so it orders any mix of the tool's case names. Apply to the
combined case dict before a single push so STLD IDs come out sequential.
"""
from __future__ import annotations

_DIR = {"+X": 0, "-X": 1, "+Y": 2, "-Y": 3,
        "+X+Y": 4, "+X-Y": 5, "-X+Y": 6, "-X-Y": 7}    # diagonals (C3/C4)
_GCPI = {"+GCpi": 0, "-GCpi": 1}
_E = {"e+": 0, "e-": 1}


def case_sort_key(name: str) -> tuple:
    """5-tuple sort key for a generated load-case name."""
    if name == "Dead":
        return (0, 0, 0, 0, 0)
    if name == "Roof Live":
        return (1, 0, 0, 0, 0)
    p = name.split()
    gcpi = _GCPI.get(p[-1], 9)
    if p[0] == "Wind":                       # "Wind +X +GCpi"
        return (2, _DIR.get(p[1], 9), 0, 0, gcpi)
    if p[0] == "MWFRS":                       # "MWFRS C2 +X e+ +GCpi"
        cnum = int(p[1][1:])                  # C1 -> 1
        d = _DIR.get(p[2], 9)
        e = _E.get(p[3], -1) if len(p) == 5 else -1   # e only on Case 2 & 4
        return (3, cnum, d, e, gcpi)
    return (9, 0, 0, 0, 0)


def order_cases(cases: dict) -> dict:
    """Return a new dict with the cases in canonical professional order."""
    return {k: cases[k] for k in sorted(cases, key=case_sort_key)}
