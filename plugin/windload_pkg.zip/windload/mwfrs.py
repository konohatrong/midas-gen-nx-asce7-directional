"""ASCE 7-22 Fig 27.3-8 — MWFRS Directional FOUR load cases (with torsion).

  Case 1: full pressures, each principal axis separately.            factor 1.0
  Case 2: 0.75 pressures + torsion M_T (e = +/-0.15 B), per axis.    factor 0.75
  Case 3: 0.75 pressures on BOTH axes simultaneously (diagonal).     factor 0.75
  Case 4: 0.5625 (=0.75^2) on both axes + torsion, simultaneously.   factor 0.5625

Torsion representation (chosen #2): **linear-graded frame line loads**. Each
horizontal member load is scaled by a linear factor along the building so the
lateral resultant shifts by e = 0.15 B — reproducing the design base shear AND
base torsion using only line loads (no rigid diaphragm needed). The vertical
(roof uplift, LZ) loads are scaled by the case factor only (they carry no plan
torsion). Mean of the per-member gradient (weighted by each member's horizontal
force) is 1.0, so the scaled base shear is exactly factor x full.

Pure (builds on loads.compute_loads); no MIDAS.
"""
from __future__ import annotations

from dataclasses import replace

from .geometry import Building
from .loads import WindParams, compute_loads, LoadSegment, MemberLoad

CASE_FACTORS = {1: 1.0, 2: 0.75, 3: 0.75, 4: 0.5625}
ECCENTRICITY = 0.15            # e = 0.15 B  (Fig 27.3-8)

_HORIZ = {"+X": "GX", "-X": "GX", "+Y": "GY", "-Y": "GY"}


def _member_x(b: Building, m: MemberLoad):
    """X position of a Y-loaded member, for parallel-wind torsion. Long-wall columns
    use their per-frame wall X (taper-aware); posts use their gable-end X."""
    if m.role == "WWcol":
        return b.wall_x_at(m.frame, False) if isinstance(m.frame, int) else 0.0
    if m.role == "LWcol":
        return b.wall_x_at(m.frame, True) if isinstance(m.frame, int) else b.span
    if isinstance(m.frame, str) and m.frame.startswith("END") and \
            m.role.startswith("post"):
        e = int(m.frame[3:])
        p = int(m.role[4:])
        for ep in b.end_posts():
            if ep.end_idx == e and ep.post_idx == p:
                return ep.x
    return None


def _seg_force(seg: LoadSegment) -> float:
    """Relative magnitude of a segment's line load (for gradient weighting)."""
    return abs((seg.w0 + seg.w1) / 2.0) * abs(seg.d1 - seg.d0)


def _gradient(items, e_abs: float):
    """Linear multipliers g_i (force-weighted mean 1) that shift the resultant of
    `items` [(position, weight)] by +e_abs. Returns list aligned to items."""
    pos = [p for p, _ in items]
    wt = [w for _, w in items]
    sw = sum(wt)
    if sw <= 0 or len(items) < 2:
        return [1.0] * len(items)
    pc = sum(w * p for p, w in items) / sw
    var = sum(w * (p - pc) ** 2 for p, w in items)
    if var <= 1e-12:
        return [1.0] * len(items)
    alpha = e_abs * sw / var
    return [1.0 + alpha * (p - pc) for p in pos]


def _scale(members, factor: float):
    """Copy members with every segment scaled by `factor`."""
    out = []
    for m in members:
        segs = [LoadSegment(s.d0, s.d1, s.w0 * factor, s.w1 * factor,
                            s.direction, s.pressure * factor) for s in m.segments]
        out.append(replace(m, segments=segs))
    return out


def _apply_torsion(members, b: Building, direction: str, factor: float,
                   e_sign: int):
    """Scale by `factor`; additionally grade the horizontal loads so the lateral
    resultant moves by e_sign*0.15*B. Vertical loads get `factor` only."""
    hdir = _HORIZ[direction]
    normal = direction in ("+X", "-X")
    B = b.length if normal else b.span        # dimension perpendicular to the wind
    e = e_sign * ECCENTRICITY * B

    # collect the horizontal-carrying members + their position & weight
    idx, items = [], []
    for i, m in enumerate(members):
        hw = sum(_seg_force(s) for s in m.segments if s.direction == hdir)
        if hw <= 0:
            continue
        # normal wind: torsion arm = the member's own Y (leeward column may sit
        # at a different Y on SKEWED frames -> y_at handles it)
        pos = (b.y_at(m.frame, leeward=(m.role == "LWcol"))
               if normal and isinstance(m.frame, int) else _member_x(b, m))
        if pos is None:
            continue
        idx.append(i)
        items.append((pos, hw))
    g = _gradient(items, e)
    gmap = {i: gi for i, gi in zip(idx, g)}

    out = []
    for i, m in enumerate(members):
        gi = gmap.get(i, 1.0)
        segs = []
        for s in m.segments:
            mult = factor * (gi if s.direction == hdir else 1.0)
            segs.append(LoadSegment(s.d0, s.d1, s.w0 * mult, s.w1 * mult,
                                    s.direction, s.pressure * mult))
        out.append(replace(m, segments=segs))
    return out


def _merge(*member_lists):
    """Concatenate member-load lists (Case 3/4 act on both axes at once)."""
    out = []
    for lst in member_lists:
        out.extend(lst)
    return out


# --- Case 3/4 need roof and walls handled DIFFERENTLY (Fig 27.3-8 Note 2) ------
C3_ROOF_FACTOR = 1.0       # C3 roof = 100% of the larger Case-1 roof pressure
C4_ROOF_FACTOR = 0.75      # C4 roof = 100% of the larger Case-2 roof (= 0.75 x C1)


def _is_roof(m: MemberLoad) -> bool:
    """A roof member: all its segments are uplift (LZ)."""
    return bool(m.segments) and all(s.direction == "LZ" for s in m.segments)


def _walls(members, factor: float):
    """Non-roof members scaled by `factor` (roof handled by _roof_envelope)."""
    out = []
    for m in members:
        if _is_roof(m):
            continue
        out.append(replace(m, segments=[
            LoadSegment(s.d0, s.d1, s.w0 * factor, s.w1 * factor, s.direction,
                        s.pressure * factor) for s in m.segments]))
    return out


def _walls_torsion(members, b: Building, direction: str, factor: float,
                   e_sign: int):
    """Wall (non-roof) members with the case factor + torsion gradient (Case 4)."""
    return _apply_torsion([m for m in members if not _is_roof(m)], b, direction,
                          factor, e_sign)


def _seg_at(segs, d: float):
    for s in segs:
        if s.d0 - 1e-9 <= d <= s.d1 + 1e-9:
            return s
    return segs[0] if segs else None


def _roof_envelope(mx, my, factor: float):
    """Fig 27.3-8 Note 2: for Cases 3/4 the roof on any area = 100% of the LARGER
    of the two principal directions' roof pressures (NOT the sum), times `factor`
    (1.0 for C3 -> larger Case-1 roof; 0.75 for C4 -> larger Case-2 roof). Overlays
    the two directions' D-zones and takes the larger-magnitude uplift per sub-area.
    """
    rx = {(m.frame, m.role): m for m in mx if _is_roof(m)}
    ry = {(m.frame, m.role): m for m in my if _is_roof(m)}
    out = []
    for key, mxm in rx.items():
        sx = mxm.segments
        sy = ry[key].segments if key in ry else []
        bps = sorted({round(s.d0, 9) for s in sx} | {round(s.d1, 9) for s in sx}
                     | {round(s.d0, 9) for s in sy} | {round(s.d1, 9) for s in sy}
                     | {0.0, 1.0})
        segs = []
        for a, b in zip(bps, bps[1:]):
            if b - a <= 1e-9:
                continue
            mid = (a + b) / 2.0
            sxa, sya = _seg_at(sx, mid), _seg_at(sy, mid)
            wx = sxa.w0 if sxa else 0.0
            wy = sya.w0 if sya else 0.0
            px = sxa.pressure if sxa else 0.0
            py = sya.pressure if sya else 0.0
            w = wx if abs(wx) >= abs(wy) else wy          # larger-magnitude uplift
            p = px if abs(px) >= abs(py) else py
            segs.append(LoadSegment(a, b, w * factor, w * factor, "LZ", p * factor))
        out.append(replace(mxm, segments=segs))
    return out


def mwfrs_cases(building: Building, wind: WindParams,
                gcpi_signs=(+1, -1), e_signs=(+1, -1),
                axes=("+X", "-X", "+Y", "-Y")) -> dict:
    """Build the FULL ASCE 7-22 Fig 27.3-8 MWFRS directional set.

    Wind is applied in BOTH senses of each axis (default +X,-X,+Y,-Y) — required
    for asymmetric/tapered buildings, where -X is NOT the mirror of +X. With the
    defaults this yields 48 cases:
      C1  4 dirs x +/-GCpi                      = 8   (full)
      C2  4 dirs x +/-GCpi x +/-e               = 16  (torsion)
      C3  4 (+/-X,+/-Y) diagonals x +/-GCpi     = 8   (both axes)
      C4  4 diagonals x +/-GCpi x +/-e          = 16  (both axes + torsion)
    For a symmetric building the negative senses are mirror images (redundant in
    the envelope) — pass axes=("+X","+Y") to halve the set.
    """
    xs = [d for d in axes if "X" in d] or ["+X"]
    ys = [d for d in axes if "Y" in d] or ["+Y"]
    diagonals = [(dx, dy) for dx in xs for dy in ys]
    # base must also cover the fallback axes (e.g. axes=("+X",) still needs +Y
    # for the C3/C4 diagonals)
    base_axes = list(dict.fromkeys(list(axes) + xs + ys))

    out: dict = {}
    for sign in gcpi_signs:
        gp = "+GCpi" if sign > 0 else "-GCpi"
        base = {ax: next(iter(compute_loads(building, wind, ax,
                                            gcpi_signs=(sign,)).values()))
                for ax in base_axes}

        # Case 1 — full, each direction separately
        for ax in axes:
            out[f"MWFRS C1 {ax} {gp}"] = _scale(base[ax], CASE_FACTORS[1])

        # Case 2 — 0.75 + torsion, each direction, +/-e
        for ax in axes:
            for es in e_signs:
                tag = "e+" if es > 0 else "e-"
                out[f"MWFRS C2 {ax} {tag} {gp}"] = _apply_torsion(
                    base[ax], building, ax, CASE_FACTORS[2], es)

        # Case 3 — walls 0.75 both axes; ROOF = 100% of the larger Case-1 roof
        # (Note 2), NOT summed and NOT 0.75-scaled.
        for dx, dy in diagonals:
            walls = _merge(_walls(base[dx], CASE_FACTORS[3]),
                           _walls(base[dy], CASE_FACTORS[3]))
            roof = _roof_envelope(base[dx], base[dy], C3_ROOF_FACTOR)
            out[f"MWFRS C3 {dx}{dy} {gp}"] = _merge(walls, roof)

        # Case 4 — walls 0.5625 both axes + torsion; ROOF = 100% of the larger
        # Case-2 roof (= 0.75 x Case-1), per Note 2.
        for dx, dy in diagonals:
            for es in e_signs:
                tag = "e+" if es > 0 else "e-"
                walls = _merge(
                    _walls_torsion(base[dx], building, dx, CASE_FACTORS[4], es),
                    _walls_torsion(base[dy], building, dy, CASE_FACTORS[4], es))
                roof = _roof_envelope(base[dx], base[dy], C4_ROOF_FACTOR)
                out[f"MWFRS C4 {dx}{dy} {tag} {gp}"] = _merge(walls, roof)
    return out
