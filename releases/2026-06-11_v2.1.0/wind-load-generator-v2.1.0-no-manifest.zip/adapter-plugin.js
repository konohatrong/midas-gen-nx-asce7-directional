/* Backend adapter — MIDAS PLUG-IN target: no server. MAPI goes straight to the
   GEN NX relay via fetch; the ASCE compute runs in-browser via Pyodide (the
   same validated `windload` package as the desktop tool); the calc report is
   rendered by bundled jsPDF. The shared app.js talks only to window.Backend. */
'use strict';
(function () {
  const REGIONAL = ["https://moa-engineers-kr.midasit.com:443/gen", "https://moa-engineers.midasit.com:443/gen",
    "https://moa-engineers-us.midasit.com:443/gen", "https://moa-engineers-in.midasit.com:443/gen",
    "https://moa-engineers-gb.midasit.com:443/gen"];
  const CDN = 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full';
  let py = null, BASE = null, KEY = null;
  const J = o => JSON.stringify(o);

  /* ---- MAPI layer ---- */
  async function mapi(method, cmd, body) {
    const r = await fetch(BASE + cmd, { method, headers: { 'Content-Type': 'application/json', 'MAPI-Key': KEY },
      body: body ? JSON.stringify(body) : undefined });
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (j && j.error) throw new Error(j.error.message || 'API error');
    return j;
  }
  async function getModel() {
    return { node: (await mapi('GET', '/db/NODE')).NODE || {},
             elem: (await mapi('GET', '/db/ELEM')).ELEM || {},
             grup: (await mapi('GET', '/db/GRUP')).GRUP || {} };
  }
  // PUT /db/BMLD in batches — a single huge PUT silently fails past ~1500 items
  async function putBmldChunked(assign, maxItems = 1500) {
    let batch = {}, count = 0, written = 0;
    for (const [eid, entry] of Object.entries(assign)) {
      const n = (entry.ITEMS || []).length;
      if (count && count + n > maxItems) { await mapi('PUT', '/db/BMLD', { Assign: batch }); written += count; batch = {}; count = 0; }
      batch[eid] = entry; count += n;
    }
    if (count) { await mapi('PUT', '/db/BMLD', { Assign: batch }); written += count; }
    return written;
  }

  /* ---- payload -> py-wrapper argument helpers ---- */
  const windJSON = p => { const w = { ...p.wind }; if (w.wall_zone_height == null) delete w.wall_zone_height; return J(w); };
  const dirsJSON = p => J(p.directions.length ? p.directions : ['+X']);
  const srfJSON = p => p.surfaces ? J(p.surfaces) : 'null';

  /* ---- boot: Pyodide + the windload package (local-first, CDN fallback) ---- */
  function loadScript(src) {
    return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res;
      s.onerror = () => rej(new Error('script load failed: ' + src)); document.head.appendChild(s); });
  }
  const setBoot = (m, cls) => { const b = document.getElementById('boot'); if (b) { b.textContent = m; if (cls) b.className = 'sub ' + cls; } };
  const ready = (async () => {
    let where = 'start';
    try {
      setBoot('Loading engine (Pyodide)…'); where = 'pyodide.js';
      if (typeof loadPyodide === 'undefined') { where = 'pyodide.js (CDN fallback)'; await loadScript(CDN + '/pyodide.js'); }
      where = 'Pyodide runtime (local ./pyodide/)';
      try { py = await loadPyodide({ indexURL: './pyodide/' }); }
      catch (e) { where = 'Pyodide runtime (CDN)'; setBoot('Loading engine (CDN fallback)…'); py = await loadPyodide({ indexURL: CDN + '/' }); }
      setBoot('Loading compute package…'); where = 'windload_pkg.zip';
      const buf = await (await fetch('windload_pkg.zip')).arrayBuffer();
      py.unpackArchive(buf, 'zip'); where = 'python init';
      await py.runPythonAsync('import sys; sys.path.insert(0,".")');
      await py.runPythonAsync(`
import json, windload.plugin as P
def pyTags(g,ne): return json.dumps(P.tag_summary(json.loads(g),ne))
def pyReview(n,e,g,w,d,az): return json.dumps(P.existing_model_review(json.loads(n),json.loads(e),json.loads(g),json.loads(w),json.loads(d),float(az)))
def pyAssign(n,e,g,w,d,fu,du,st,lg,bm,srf,az,mode,dead,live):
    return json.dumps(P.existing_model_assign(
        json.loads(n),json.loads(e),json.loads(g),json.loads(w),json.loads(d),
        fu,du,json.loads(st),json.loads(lg),json.loads(bm),json.loads(srf),
        float(az),mode,float(dead),float(live)))
def pyGrup(g): return json.dumps(P.grup_payload(json.loads(g)))
def pyCalcReport(n,e,g,w,d,az,mode,dead,live,meta):
    return json.dumps(P.existing_model_report(
        json.loads(n),json.loads(e),json.loads(g),json.loads(w),json.loads(d),
        float(az),mode,float(dead),float(live),json.loads(meta)))
`);
      setBoot('Engine ready ✓ (ASCE compute runs locally via Pyodide).', 'ok');
    } catch (e) {
      setBoot('Engine failed at [' + where + ']: ' + e, 'err');
      console.error('boot failed at', where, e);
      throw new Error('engine not ready — ' + e.message);
    }
  })();

  async function tagStatusNow() {
    const g = (await mapi('GET', '/db/GRUP')).GRUP || {};
    const ne = Object.keys((await mapi('GET', '/db/ELEM')).ELEM || {}).length;
    return JSON.parse(py.globals.get('pyTags')(J(g), ne));
  }

  /* ---- the calc-report PDF (same data dict as the desktop fpdf2 renderer) ---- */
  function renderReportPdf(rep) {
    const { jsPDF } = window.jspdf; const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    const M = 14; let y = 16;
    const HEAD = [14, 95, 216], MUT = [110, 116, 130], INK = [40, 45, 60];
    const text = (t, size, style, color) => { doc.setFont('helvetica', style || 'normal'); doc.setFontSize(size); doc.setTextColor(...(color || INK));
      const lines = doc.splitTextToSize(String(t), 182); if (y + lines.length * size * 0.45 > 283) { doc.addPage(); y = 16; }
      doc.text(lines, M, y); y += lines.length * (size * 0.45) + 2; };
    const kv = o => { for (const [k, v] of Object.entries(o || {})) { doc.setFontSize(8.6); if (y > 278) { doc.addPage(); y = 16; }
      doc.setTextColor(...MUT); doc.setFont('helvetica', 'normal'); doc.text(String(k), M, y);
      doc.setTextColor(...INK); doc.text(doc.splitTextToSize(String(v), 114), M + 64, y); y += 4.8; } y += 2; };
    const table = (head, bodyRows, checkCol) => { doc.autoTable({ head: [head], body: bodyRows, startY: y, margin: { left: M, right: M },
      styles: { fontSize: 7.6, cellPadding: 1.2, textColor: INK }, headStyles: { fillColor: [238, 241, 247], textColor: [30, 35, 50], fontStyle: 'bold' },
      didParseCell: d => { if (checkCol != null && d.section === 'body' && d.column.index === checkCol) { const v = String(d.cell.raw);
        d.cell.styles.fontStyle = 'bold'; d.cell.styles.textColor = (v === 'OK' || v === 'PASS') ? [46, 140, 87] : (v === 'n/a' ? MUT : [200, 60, 60]); } } });
      y = doc.lastAutoTable.finalY + 5; };
    const h1 = t => text(t, 12.5, 'bold', HEAD), h2 = t => text(t, 10, 'bold', [30, 35, 50]), b8 = (t, m) => text(t, 8.6, 'normal', m ? MUT : INK);
    text(rep.title, 15, 'bold', HEAD); (rep.credit || []).forEach(c => b8(c));
    if (rep.meta && Object.keys(rep.meta).length) kv(rep.meta);
    b8('Disclaimer: ' + rep.disclaimer, true);
    h1('Inputs'); h2('Geometry'); kv(rep.inputs.geometry); h2('Wind / load parameters'); kv(rep.inputs.wind);
    const s1 = rep.step1_velocity_pressure; h1('Step 1 - Velocity pressure q_z (Eq 26.10-1)');
    b8(s1.formula); b8(s1.reference, true);
    table(['location', 'z', 'Kz', 'q_z'], s1.rows.map(r => [r.location, r.z, r.Kz, r.qz])); b8('q_h (mean roof height) = ' + s1.qh);
    const s2 = rep.step2_coefficients; h1('Step 2 - Pressure coefficients (Fig 27.3-1)'); kv(s2.ratios);
    table(['surface', 'Cp', 'use with', 'basis'], s2.walls.map(r => [r.surface, r.Cp, r['use with'], r.ref]));
    h2('Roof Cp per direction'); kv(Object.fromEntries(Object.entries(s2.roof).filter(([k]) => k !== 'reference')));
    b8('Internal pressure: GCpi = ' + s2.GCpi);
    const s3 = rep.step3_design_pressures; h1('Step 3 - Net design pressures (Eq 27.3-1)');
    b8(s3.formula); b8(s3.internal_check, true);
    for (const [d, blk] of Object.entries(s3.directions)) { h2('Wind ' + d + ' (interior frame ' + s3.interior_frame + ')');
      table(['surface', 'axis', 'zone', 'p(+GCpi)', 'p(-GCpi)', 'p_ext', 'p_int', 'CHECK'],
        blk.rows.map(r => [r.surface, r.axis, r.zone, r.p_plus, r.p_minus, r.p_ext, r.p_int, r.CHECK]), 7); }
    const s4 = rep.step4_member_loads; h1('Step 4 - Member line loads (w = p x tributary)');
    b8(s4.note, true); kv({ 'tributary widths per frame': JSON.stringify(s4.tributaries) });
    for (const [d, dc] of Object.entries(s4.directions)) for (const [cname, rows] of Object.entries(dc)) { h2(cname);
      table(['frame', 'role', 'axis', 'D (rel.)', 'w0', 'w1', 'p'], rows.map(r => [r.frame, r.role, r.axis, r.D, r.w0, r.w1, r.p])); }
    if (rep.step5_mwfrs) { const s5 = rep.step5_mwfrs; h1('Step 5 - MWFRS design wind load cases (Fig 27.3-8)');
      table(['case', 'factor', 'description'], s5.definitions.map(d => [d.case, d.factor, d.desc])); kv(s5.eccentricity);
      b8(s5.shear_note, true); h2(s5.n_cases + ' cases - base-shear ratio validation');
      table(['case', 'factor', 'ratio checks', 'CHECK'], s5.rows.map(r => [r.case, r.factor, r.checks, r.CHECK]), 3); }
    if (rep.gravity) { h1('Roof gravity loads (Dead / Roof Live)'); b8(rep.gravity.note, true);
      for (const [cname, rows] of Object.entries(rep.gravity.cases)) { h2(cname);
        table(['frame', 'role', 'w (line load)'], rows.map(r => [r.frame, r.role, r.w])); } }
    const v = rep.validation_summary; h1('Validation summary');
    table(['check', 'result'], [['Step 3: internal-pressure constant on every row', v.internal_pressure_rows],
      ['Step 5: MWFRS base-shear ratios = Fig 27.3-8 factors', v.mwfrs_shear_ratios], ['ALL CHECKS', v.all_pass ? 'OK' : 'MISMATCH']], 1);
    return doc;
  }

  /* ---- the Backend interface ---- */
  window.Backend = {
    name: 'plugin',
    can: { generate: false, mwfrsOnly: false, clear: false },
    ready,

    async connect(p) {
      KEY = (p.mapi_key || '').trim();
      if (!KEY) throw new Error('Paste the MAPI-Key first.');
      const urls = window.__MIDAS_BASE ? [window.__MIDAS_BASE, ...REGIONAL] : REGIONAL;
      let hit = null;
      for (const u of urls) { BASE = u; try { const s = await mapi('GET', '/ope/PROJECTSTATUS'); if (s && s.PROJECTSTATUS) { hit = u; break; } } catch (e) {} }
      if (!hit) throw new Error('Could not reach GEN NX. Open it, enable the API, refresh the key.');
      const tags = await tagStatusNow();
      return { desc: hit.split('//')[1].split(':')[0], tags };
    },

    async createGroups() {
      if (!KEY) throw new Error('Connect first.');
      const grup = (await mapi('GET', '/db/GRUP')).GRUP || {};
      const res = JSON.parse(py.globals.get('pyGrup')(J(grup)));
      if (Object.keys(res.assign.Assign).length) await mapi('PUT', '/db/GRUP', res.assign);
      return res;
    },

    async tagStatus() { if (!KEY) throw new Error('Connect first.'); return tagStatusNow(); },

    async preview() { throw new Error('Generate path is desktop-only.'); },

    async pullReview(p) {
      if (!KEY) throw new Error('Connect first.');
      const m = await getModel();
      return JSON.parse(py.globals.get('pyReview')(J(m.node), J(m.elem), J(m.grup),
        windJSON(p), dirsJSON(p), p.ridge_azimuth_deg));
    },

    async apply(p) {
      if (!KEY) throw new Error('Connect first.');
      const m = await getModel();
      const unit = (await mapi('GET', '/db/UNIT')).UNIT || {}; const u = Object.values(unit)[0] || {};
      const st = (await mapi('GET', '/db/STLD')).STLD || {};
      const lg = (await mapi('GET', '/db/LDGR')).LDGR || {};
      const bm = (await mapi('GET', '/db/BMLD')).BMLD || {};      // non-destructive merge
      const res = JSON.parse(py.globals.get('pyAssign')(J(m.node), J(m.elem), J(m.grup),
        windJSON(p), dirsJSON(p), u.FORCE || 'KN', u.DIST || 'M', J(st), J(lg), J(bm),
        srfJSON(p), p.ridge_azimuth_deg, p.mode, String(p.dead || 0), String(p.live || 0)));
      if (Object.keys(res.stld.Assign).length) await mapi('PUT', '/db/STLD', res.stld);
      if (Object.keys(res.ldgr.Assign).length) await mapi('PUT', '/db/LDGR', res.ldgr);
      if (Object.keys(res.bmld.Assign).length) await putBmldChunked(res.bmld.Assign);
      return { cases: res.cases || [], loads: res.bmld_count ?? 0, preserved: true,
               report: res.report, preview: res.preview };
    },

    async report(p) {
      if (!KEY) throw new Error('Connect first.');
      if (typeof window.jspdf === 'undefined') throw new Error('PDF library not loaded (vendor/ missing).');
      const m = await getModel();
      const meta = J({ generated: new Date().toISOString().slice(0, 16).replace('T', ' '),
        model: 'pulled from GEN NX', 'load set': p.mode, 'plug-in': 'v' + (window.__APP_VERSION || '') });
      const rep = JSON.parse(py.globals.get('pyCalcReport')(J(m.node), J(m.elem), J(m.grup),
        windJSON(p), dirsJSON(p), p.ridge_azimuth_deg, p.mode, String(p.dead || 0), String(p.live || 0), meta));
      renderReportPdf(rep).save('wind_load_calc_report.pdf');
      const ok = rep.validation_summary.all_pass;
      return { note: ok ? '(all checks PASS)' : '(CHECK FAILURES — review!)', level: ok ? 'ok' : 'warn' };
    },

    /* post-DOM hook: MIDAS query-param key prefill + controller-bar padding */
    init() {
      const p = new URLSearchParams(location.search);
      if ([...p.keys()].length) console.log('MIDAS query params:', Object.fromEntries(p));
      for (const k of ['mapiKey', 'mapi_key', 'MAPI-Key', 'apiKey', 'key', 'productKey']) {
        const v = p.get(k);
        if (v) { document.getElementById('key').value = v;
          const cs = document.getElementById('connStatus');
          cs.textContent = 'Key received from MIDAS — click Connect.'; break; }
      }
      for (const u of ['baseUrl', 'base_url', 'baseURL']) { const v = p.get(u); if (v) { window.__MIDAS_BASE = v; break; } }
      const c = document.getElementById('midas-controller');
      function fit() { let h = 0; if (c) { h = c.offsetHeight || (c.firstElementChild && c.firstElementChild.offsetHeight) || 0; }
        if (h > 0) document.body.style.paddingTop = (h + 12) + 'px'; }
      fit(); setTimeout(fit, 400); setTimeout(fit, 1200);
      try { if (window.ResizeObserver && c) new ResizeObserver(fit).observe(c); } catch (e) {}
    },
  };
})();
