/* Shared UI logic — single source for BOTH the desktop GUI and the MIDAS
   plug-in (copied by make_ui.py; edit here, never in the outputs).
   All backend access goes through window.Backend (adapter-server.js or
   adapter-plugin.js). Feature drift between the two targets is structurally
   impossible: there is one form and one set of handlers. */
'use strict';
const $ = id => document.getElementById(id);
let SRC = 'generate', ROOF = 'gable', MODE = 'wind';

/* ---------- capability gating (the ONLY per-target divergence) ---------- */
(function gate() {
  for (const el of document.querySelectorAll('[data-cap]')) {
    if (!Backend.can[el.dataset.cap]) el.classList.add('hide');
  }
  if (!Backend.can.generate) { SRC = 'existing'; }
})();

/* ---------- mode / source / roof selectors ---------- */
function setSrc(s) {
  SRC = s;
  if ($('srcGen')) { $('srcGen').classList.toggle('on', s === 'generate'); $('srcExist').classList.toggle('on', s === 'existing'); }
  $('genPanel').classList.toggle('hide', s !== 'generate' || !Backend.can.generate);
  $('existPanel').classList.toggle('hide', s !== 'existing');
  if (s === 'existing' && MODE === 'mwfrs') setMode('full');   // MWFRS-only is generate-path
  setMode(MODE);
}
function setMode(m) {
  MODE = m;
  const map = { modeWind: 'wind', modeWM: 'wind_mwfrs', modeMwfrs: 'mwfrs', modeFull: 'full' };
  document.querySelectorAll('.md').forEach(b => b.classList.toggle('on', map[b.id] === m));
  $('gravRow').classList.toggle('hide', m !== 'full');
  if ($('modeMwfrs')) $('modeMwfrs').disabled = (SRC === 'existing');
  if (m !== 'wind') document.querySelectorAll('.dir').forEach(c => c.checked = true);  // multi-case sets want all 4
  $('modeNote').textContent =
    m === 'full' ? '58 cases with all 4 directions: Dead, Roof Live, 8 directional wind, 48 MWFRS C1–C4 — pushed in canonical order.'
    : m === 'wind_mwfrs' ? '56 cases: 8 directional wind (±X/±Y × ±GCpi) + 48 MWFRS C1–C4 — no gravity cases.'
    : m === 'mwfrs' ? '48 MWFRS design cases (C1 full, C2 torsion, C3 diagonal, C4 diagonal+torsion). Generate path only.'
    : 'Directional wind only: each checked direction × ±GCpi.';
}
function setRoof(r) {
  ROOF = r;
  document.querySelectorAll('.rt').forEach(b => b.classList.toggle('on', b.dataset.rt === r));
  $('theta2Row').classList.toggle('hide', r === 'monoslope');
  $('rtNote').textContent = r === 'monoslope' ? '(monoslope)' : (r === 'pitch' ? '(steep gable)' : '');
  drawSketch();
}

/* ---------- the single payload shape both adapters consume ---------- */
function bays() { return $('bays').value.split(',').map(s => parseFloat(s.trim())).filter(x => !isNaN(x)); }
function optNum(id) { const v = $(id).value.trim(); return v === '' ? null : +v; }
function payload() {
  const a2 = $('theta2').value.trim();
  const srfAll = [...document.querySelectorAll('.srf')], srfOn = srfAll.filter(c => c.checked).map(c => c.value);
  return {
    source: SRC,
    geometry: { bays: bays(), span: +$('span').value, eave_height: +$('eave').value, roof_angle_deg: +$('theta').value,
      roof_angle_deg2: (a2 === '' ? null : +a2), n_end_posts: +$('posts').value, roof_type: ROOF,
      width_windward: optNum('wWW'), width_leeward: optNum('wLW'), span_end: optNum('spanEnd') },
    wind: { V: +$('V').value, exposure: $('exp').value, units: $('units').value, Kzt: +$('kzt').value, Ke: +$('ke').value,
      G: +$('g').value, enclosure: $('encl').value, wall_zone_height: optNum('wzh'), wall_qz_at: $('wqz').value },
    directions: [...document.querySelectorAll('.dir:checked')].map(c => c.value),
    surfaces: (srfOn.length === srfAll.length ? null : srfOn),
    ridge_azimuth_deg: ($('ridgeSel').value === 'custom' ? (+$('ridgeAng').value || 90) : +$('ridgeSel').value),
    mode: MODE, dead: +$('dead').value || 0, live: +$('live').value || 0,
    mapi_key: $('key').value.trim() || null,
    clear: ($('clear') && Backend.can.clear) ? $('clear').checked : false,
  };
}

/* ---------- rendering ---------- */
function num(x) { const v = Number(x); return isNaN(v) ? x : (Math.abs(v) < 10 ? v.toFixed(2) : v.toFixed(1)); }
function pcell(v) { if (v === undefined) return '<td>—</td>'; return `<td class="${v < 0 ? 'neg' : 'pos'}">${num(v)}</td>`; }
function pressuresHTML(d) {
  const g = d.geometry, w = d.wind;
  let h = `<div class="card"><h3>Computed model</h3><div class="kv">
    <span><b>Frames</b> ${g.frames}</span><span><b>Span</b> ${g.span}</span><span><b>Eave</b> ${g.eave}</span><span><b>Ridge</b> ${g.ridge}</span>
    <span><b>θ</b> ${g.roof_angle_deg}°</span><span><b>h</b> ${g.h}</span><span><b>h/L</b> ${g.h_over_L}</span><span><b>End posts</b> ${g.end_posts}</span>
    <span><b>V</b> ${w.V}</span><span><b>Exp</b> ${w.exposure}</span><span><b>q_h</b> ${w.qh} ${w.pressure_unit}</span><span><b>GCpi</b> ±${w.GCpi}</span>
    </div><div class="muted" style="margin-top:8px">Tributaries: ${g.tributaries.join(', ')} · ${d.total_cases} cases · ${d.total_member_loads} member loads</div></div>`;
  for (const dir of Object.keys(d.directions)) {
    const dd = d.directions[dir], cn = dd.cases;
    const rows = dd.pressures.map(p => `<tr><td>${p.role}</td><td>${p.dir}</td><td>${p.zone}</td>${pcell(p[cn[0]])}${pcell(p[cn[1]])}</tr>`).join('');
    h += `<div class="card"><h3>Wind ${dir} — net pressures (${w.pressure_unit})</h3>
      <table><thead><tr><th>Surface</th><th>Dir</th><th>Zone</th><th>+GCpi</th><th>−GCpi</th></tr></thead><tbody>${rows}</tbody></table>
      <div class="muted" style="margin-top:6px">Cases: ${cn.join(' · ')}</div></div>`;
  }
  return h;
}
function reportHTML(r) {
  const wc = r.warnings.length ? `<span class="warn">⚠ ${r.warnings.length} warning(s): ${r.warnings.join('; ')}</span>` : '<span class="ok">✓ no warnings</span>';
  const notes = (r.notes && r.notes.length) ? `<div class="muted" style="margin-top:6px">ℹ ${r.notes.join(' · ')}</div>` : '';
  const th = (r.roof_angle_deg2 != null) ? `${num(r.roof_angle_deg)}° / ${num(r.roof_angle_deg2)}°` : `${num(r.roof_angle_deg)}°`;
  return `<div class="card"><h3>Reconstructed model (verify) — ${wc}</h3><div class="kv">
    <span><b>Roof</b> ${r.roof_type || 'gable'}</span><span><b>Frames</b> ${r.n_frames}</span><span><b>Span</b> ${num(r.span)}</span><span><b>Eave</b> ${num(r.eave_height)}</span>
    <span><b>Ridge</b> ${num(r.ridge_height)}</span><span><b>θ</b> ${th}</span><span><b>End posts</b> ${r.end_posts}</span>
    </div><div class="muted" style="margin-top:8px">Frames at: ${(r.frame_positions || []).map(num).join(', ')} · roles: ${JSON.stringify(r.role_counts)}</div>${notes}</div>`;
}
function setStatus(el, t, c) { $(el).textContent = t; $(el).className = 's ' + (c || 'muted'); }
async function run(btn, statusEl, fn, msg) {
  btn.disabled = true; setStatus(statusEl, msg);
  try { await Backend.ready; await fn(); }
  catch (e) { setStatus(statusEl, 'Failed: ' + e.message, 'err'); }
  finally { btn.disabled = false; }
}
function tagMsg(t) {
  if (!t) return '';
  if (t.total_elements === 0) return 'empty model — no elements yet.';
  if (!t.has_tags) return `${t.total_elements} elements · NO tagging groups that the tool recognizes — Create groups, assign elements in GEN NX, then Refresh (without tags the tool falls back to geometry).`;
  if (t.tagged_elements === 0) return `${t.group_count} tagging group(s) exist but NO elements assigned yet — assign in GEN NX, then Refresh.`;
  return `tagged ${t.tagged_elements}/${t.total_elements} elements · groups: ${Object.keys(t.groups).join(', ')}.`;
}
function tagLevel(t) { return (t && t.has_tags && t.tagged_elements > 0) ? 'ok' : 'warn'; }

/* ---------- handlers (identical on both targets) ---------- */
$('connect').onclick = () => run($('connect'), 'connStatus', async () => {
  const j = await Backend.connect(payload());
  $('n1').classList.add('done');
  setStatus('connStatus', `Connected ✓  ${j.desc}  ·  ${tagMsg(j.tags)}`, tagLevel(j.tags));
  if (!$('existPanel').classList.contains('hide')) setStatus('tagStatus', tagMsg(j.tags), tagLevel(j.tags));
}, 'Connecting…');

$('mkGroups').onclick = () => run($('mkGroups'), 'grpStatus', async () => {
  const j = await Backend.createGroups(payload());
  const c = j.created && j.created.length ? ('Created: ' + j.created.join(', ')) : 'All tagging groups already existed';
  const sk = (j.skipped && j.skipped.length) ? ('  · already present: ' + j.skipped.join(', ')) : '';
  setStatus('grpStatus', c + sk + `  · kept ${j.existing_kept} existing project group(s). Now assign elements in GEN NX, then press Refresh.`, 'ok');
}, 'Creating groups…');

$('refreshTags').onclick = () => run($('refreshTags'), 'tagStatus', async () => {
  if (!$('key').value.trim()) throw new Error('Enter the MAPI-Key and Connect first.');
  const t = await Backend.tagStatus(payload());
  setStatus('tagStatus', 'Refreshed · ' + tagMsg(t), tagLevel(t));
}, 'Reading tags…');

$('preview').onclick = () => run($('preview'), 'status', async () => {
  if (SRC === 'generate') {
    const d = await Backend.preview(payload());
    $('out').innerHTML = pressuresHTML(d);
    setStatus('status', 'Preview ready ✓', 'ok');
  } else {
    const d = await Backend.pullReview(payload());
    $('out').innerHTML = reportHTML(d.report) + pressuresHTML(d.preview);
    const wl = d.report.warnings.length, nl = (d.report.notes || []).length;
    setStatus('status', wl ? ('Pulled with ' + wl + ' warning(s) — verify') : (nl ? ('Pulled & previewed ✓ · ' + nl + ' note(s)') : 'Pulled & previewed ✓'), wl ? 'warn' : 'ok');
  }
}, 'Computing…');

$('apply').onclick = () => run($('apply'), 'status', async () => {
  const j = await Backend.apply(payload());
  $('out').innerHTML = (j.report ? reportHTML(j.report) + pressuresHTML(j.preview)
    : `<div class="card"><h3>Applied to GEN NX ✓</h3><pre>${JSON.stringify(j.raw || j, null, 2)}</pre></div>`);
  setStatus('status', `Pushed ${j.loads} loads in ${j.cases.length} cases ✓${j.preserved ? ' (other cases preserved)' : ''}`, 'ok');
}, 'Applying to GEN NX…');

$('report').onclick = () => run($('report'), 'status', async () => {
  const j = await Backend.report(payload());   // adapter performs the download
  setStatus('status', `Report downloaded ✓ ${j.note || ''}`, j.level || 'ok');
}, 'Building calculation report…');

/* ---------- model preview sketch (generate path) ---------- */
function L(x1, y1, x2, y2, c, w) { return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${c || '#cfd6e4'}" stroke-width="${w || 2}"/>`; }
function T(x, y, t, c) { return `<text x="${x}" y="${y}" fill="${c || '#9aa3b2'}" font-size="11">${t}</text>`; }
function CIR(x, y, r, f) { return `<circle cx="${x}" cy="${y}" r="${r}" fill="${f}" stroke="#0b0e14" stroke-width="1"/>`; }
function drawSketch() {
  if (!$('sketch')) return;
  const span = +$('span').value || 1, eave = +$('eave').value || 1, th = (+$('theta').value || 0) * Math.PI / 180;
  const t2raw = $('theta2').value.trim();
  const th2 = (ROOF !== 'monoslope' && t2raw !== '') ? (+t2raw) * Math.PI / 180 : th;
  const bs = bays(), len = bs.reduce((a, b) => a + b, 0) || 1, posts = +$('posts').value || 0;
  const tl = Math.tan(th), tr = Math.tan(th2);
  const xr = (ROOF === 'monoslope') ? span : ((tl + tr) ? span * tr / (tl + tr) : span / 2);
  const rise = (ROOF === 'monoslope') ? span * tl : xr * tl;
  const maxH = eave + rise;
  const ex = 40, ey = 30, ew = 300, eh = 200, sx = ew / span, sz = eh / (maxH * 1.15);
  const X = x => ex + x * sx, Z = z => ey + eh - z * sz;
  let s = '';
  s += T(ex, ey - 8, 'ELEVATION (gable frame)');
  if (ROOF === 'monoslope') {
    s += L(X(0), Z(0), X(0), Z(eave));
    s += L(X(span), Z(0), X(span), Z(maxH));
    s += L(X(0), Z(eave), X(span), Z(maxH), '#6bc0e5', 2.5);
  } else {
    s += L(X(0), Z(0), X(0), Z(eave));
    s += L(X(span), Z(0), X(span), Z(eave));
    s += L(X(0), Z(eave), X(xr), Z(maxH), '#6bc0e5', 2.5);
    s += L(X(xr), Z(maxH), X(span), Z(eave), '#6bc0e5', 2.5);
  }
  s += L(X(0), Z(0), X(span), Z(0), '#3a4254', 1);
  s += T(X(span / 2) - 14, Z(0) + 16, span + ' span');
  s += T(ex - 30, Z(eave / 2), eave + '');
  for (let p = 1; p <= posts; p++) {
    const xp = p * span / (posts + 1);
    const zt = (ROOF === 'monoslope') ? eave + xp * tl : (xp <= xr ? eave + xp * tl : eave + (span - xp) * tr);
    s += L(X(xp), Z(0), X(xp), Z(zt), '#e0a32e', 1.5);
  }
  const px = 390, py = 40, pw = 270, ph = 180, pxs = pw / len, pys = ph / span;
  const PX = x => px + x * pxs, PY = y => py + y * pys;
  s += T(px, py - 12, 'PLAN (frames along ridge)');
  s += `<rect x="${px}" y="${py}" width="${pw}" height="${ph}" fill="none" stroke="#3a4254"/>`;
  let acc = 0; const fy = [0, ...bs.map(b => acc += b)];
  fy.forEach((y, i) => { const c = (i === 0 || i === fy.length - 1) ? '#e5a06b' : '#cfd6e4'; s += L(PX(y), PY(0), PX(y), PY(span), c, (i === 0 || i === fy.length - 1) ? 2.5 : 1.5); });
  s += T(px, py + ph + 16, len + ' long · ' + fy.length + ' frames · bays ' + bs.join(','));
  s += `<text x="${px + pw - 2}" y="${py + ph + 16}" fill="#e5a06b" font-size="11" text-anchor="end">orange = end frames (corners)</text>`;
  $('sketch').innerHTML = s;
}

/* ---------- tagging instruction diagram ---------- */
const C_WW = '#6bc0e5', C_LW = '#e5a06b', C_WR = '#46c07a', C_LR = '#c98bdb', C_RF = '#54c8b8', C_EP = '#e0a32e', C_CN = '#ffffff';
function drawLegend() {
  let s = T(30, 22, 'Assign each element of a typical frame to a Structure Group:', '#cfd6e4');
  (function () {
    const ox = 70, oy = 60, w = 240, h = 130, eave = h * 0.55, rise = h * 0.45;
    const X = x => ox + x * w, Z = z => oy + h - z;
    s += T(ox, oy - 12, 'GABLE — section', '#cfd6e4');
    s += L(X(0), Z(0), X(0), Z(eave), C_WW, 5);
    s += L(X(1), Z(0), X(1), Z(eave), C_LW, 5);
    s += L(X(0), Z(eave), X(0.5), Z(eave + rise), C_WR, 5);
    s += L(X(0.5), Z(eave + rise), X(1), Z(eave), C_LR, 5);
    s += L(X(0), Z(0), X(1), Z(0), '#3a4254', 1);
    s += L(X(0.5), Z(0), X(0.5), Z(eave + rise), C_EP, 3);
    s += T(X(0) - 46, Z(eave * 0.5), 'WWcol', C_WW);
    s += T(X(1) + 4, Z(eave * 0.5), 'LWcol', C_LW);
    s += T(X(0.13), Z(eave + rise * 0.55) - 2, 'WWroof', C_WR);
    s += T(X(0.6), Z(eave + rise * 0.55) - 2, 'LWroof', C_LR);
    s += T(X(0.5) + 5, Z(eave + rise) + 2, 'ENDWALL', C_EP);
  })();
  (function () {
    const ox = 420, oy = 60, w = 210, h = 130, low = h * 0.42, high = h * 0.9;
    const X = x => ox + x * w, Z = z => oy + h - z;
    s += T(ox, oy - 12, 'MONOSLOPE — section', '#cfd6e4');
    s += L(X(0), Z(0), X(0), Z(low), C_WW, 5);
    s += L(X(1), Z(0), X(1), Z(high), C_LW, 5);
    s += L(X(0), Z(low), X(1), Z(high), C_RF, 5);
    s += L(X(0), Z(0), X(1), Z(0), '#3a4254', 1);
    s += T(X(0) - 46, Z(low * 0.5), 'WWcol', C_WW);
    s += T(X(1) + 4, Z(high * 0.5), 'LWcol', C_LW);
    s += T(X(0.32), Z((low + high) / 2) + 16, 'ROOF', C_RF);
    s += T(ox - 4, oy + h + 20, 'one roof group: ROOF (not WW/LWroof)', '#9aa3b2');
  })();
  (function () {
    const ox = 110, oy = 300, w = 480, h = 100;
    const PX = u => ox + u * w, PY = v => oy + v * h;
    s += T(ox - 40, oy - 14, 'PLAN (looking down) — CORNER = the 4 columns at the building corners', '#cfd6e4');
    s += L(PX(0), PY(0), PX(1), PY(0), C_WW, 4);
    s += L(PX(0), PY(1), PX(1), PY(1), C_LW, 4);
    s += L(PX(0), PY(0), PX(0), PY(1), C_EP, 4);
    s += L(PX(1), PY(0), PX(1), PY(1), C_EP, 4);
    [0.34, 0.67].forEach(u => { s += L(PX(u), PY(0), PX(u), PY(1), '#3a4254', 1.5); });
    [0.34, 0.67].forEach(v => { s += CIR(PX(0), PY(v), 3, C_EP); s += CIR(PX(1), PY(v), 3, C_EP); });
    [[0, 0], [0, 1], [1, 0], [1, 1]].forEach(([u, v]) => { s += CIR(PX(u), PY(v), 6, C_CN); });
    s += T(PX(0) - 2, PY(0) - 8, 'CORNER', C_CN);
    s += T(PX(1) - 48, PY(1) + 16, 'CORNER', C_CN);
    s += T(PX(0.40), PY(0) - 8, 'WWcol wall', C_WW);
    s += T(PX(0.40), PY(1) + 16, 'LWcol wall', C_LW);
    s += T(PX(0) - 6, PY(0.5), 'ENDWALL', C_EP);
    s += T(ox - 40, oy + h + 24, 'The 4 corner columns belong to BOTH a long wall and a gable end, so they resist wind in both directions.', '#9aa3b2');
  })();
  $('legendSvg').innerHTML = s;
  const items = [['#6bc0e5', 'WWcol', 'Windward-side columns (X=0 wall)'],
    ['#e5a06b', 'LWcol', 'Leeward-side columns (X=span wall)'],
    ['#46c07a', 'WWroof', 'GABLE windward roof rafters'],
    ['#c98bdb', 'LWroof', 'GABLE leeward roof rafters'],
    ['#54c8b8', 'ROOF', 'MONOSLOPE roof rafters (single group)'],
    ['#e0a32e', 'ENDWALL0 / ENDWALL1', 'Gable-end wind posts — one group per end (Y-min / Y-max)'],
    ['#ffffff', 'CORNER', 'The 4 corner columns (end frames)']];
  $('legendKey').innerHTML = items.map(i => `<span class="sw" style="border-color:${i[0]}"></span><span><b style="color:${i[0]}">${i[1]}</b> — ${i[2]}</span>`).join('');
}

/* ---------- init ---------- */
['bays', 'span', 'eave', 'theta', 'theta2', 'posts'].forEach(id => $(id).addEventListener('input', drawSketch));
drawSketch();
drawLegend();
setSrc(Backend.can.generate ? 'generate' : 'existing');
if (Backend.init) Backend.init();        // adapter post-DOM hook (key prefill, boot UI…)
